HostedZoneId="Z01256742LT7N6HOSYVXY"
HostedZoneRevId="Z013746639FG84NZ5P8DH"
Region="us-east-1"
pDevVpcId="vpc-0d8d2e2799ce24755"
pTestVpcId="vpc-0cfde41e18091467e"

set -uo pipefail
set -x

# In the Network Account

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${HostedZoneId}" \
  --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile net

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${HostedZoneRevId}" \
  --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile net

# Target accounts

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${HostedZoneId}" \
  --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile dev

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${HostedZoneRevId}" \
  --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile dev

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${HostedZoneId}" \
  --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile test

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${HostedZoneRevId}" \
  --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile test
