#!/usr/bin/env bash

set -euo pipefail


VpcId=vpc-00cc9f6d1ca20def3
VpcCidrBlock=172.26.16.0/20
SubnetIds="subnet-0b3cb7798ee6dd503\\,subnet-0f42689ade9d7eecb"
Profile=lab

aws cloudformation create-stack \
  --stack-name create-ssm-ec2-ep \
  --template-body file://./CF-AWS-SSM-EC2-Endpoints.yaml \
  --region us-east-1 \
  --capabilities CAPABILITY_IAM \
  --profile "${Profile}" \
  --parameters ParameterKey=VpcId,ParameterValue="${VpcId}" \
               ParameterKey=VpcCidrBlock,ParameterValue="${VpcCidrBlock}" \
               ParameterKey=SubnetIds,ParameterValue="${SubnetIds}"