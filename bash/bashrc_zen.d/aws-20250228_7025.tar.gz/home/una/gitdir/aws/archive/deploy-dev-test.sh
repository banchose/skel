pTestTransitGatewayAttachmentId=
pTestTransitGatewayRouteTableId=
pTransitGatewayId=""
pInspectvMXToken=
Region=us-east-1

# Create Network

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK \
  --template-body file://./HRI-BIGNETWORK.yaml \
  --capabilities CAPABILITY_IAM \
  --parameters ParameterKey="pInspectvMXToken",ParameterValue="f98291188bdd6df6301041cc62abf716/4e6f3671ea4257703c746f17545eb90176bc604786eda4a38d8005643053c21cee04c21d617332a823c74279a9f48462a79826da0324f5757e607beb66526bb3/cda235ed58889f94ceb53d119d2bacc427af4ac45bc8b7a18a65eb86777a34eb" \
  --region "${Region}" \
  --profile net

# Create Dev

aws cloudformation create-stack \
  --stack-name HRI-DEV --template-body file://./HRI-DEV.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameters ParameterKey="pInspectTransitGateway",ParameterValue="tgw-067f2cd08edc054d2" \
  --region "${Region}" \
  --profile dev

# Create Test

aws cloudformation create-stack \
  --stack-name HRI-TEST --template-body file://./HRI-TEST.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameters ParameterKey="pInspectTransitGateway",ParameterValue="tgw-067f2cd08edc054d2" \
  --region "${Region}" \
  --profile test

## Associate - in net account

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-ASSOC-DEV \
  --template-body file://HRI-BIGNETWORK-ASSC-Dev.yaml \
  --parameters ParameterKey="pTransitGatewayAttachmentId",ParameterValue="${pDevTransitGatewayAttachmentId}" \
  ParatameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${pInspectTransitGatewayRouteTableId}" \
  --region "${Region}" \
  --profile net # yes net!

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-ASSOC-TEST \
  --template-body file://HRI-BIGNETWORK-ASSC-TEST.yaml \
  --parameters ParameterKey="pTestTransitGatewayAttachmentId",ParameterValue="${pTestTransitGatewayAttachmentId}" \
  ParatameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${pInspectTransitGatewayRouteTableId}" \
  --region "${Region}" \
  --profile net # yes net!
