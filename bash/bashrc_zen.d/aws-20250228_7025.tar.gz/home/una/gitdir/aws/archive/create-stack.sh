#!/usr/bin/env bash

set -euo pipefail

vMXToken="4ff222f65381d8244e453bd447045799/49dcac132cd312119546f8ff6a2ba1fb78ad2411e8a4cc7cdb41e6ee5e95298e3233236ffe739ab4f2e262ef6419648c6ab252e3af37aa963c19657ed72850d9/d5ece55bb07df26aa13a4e208cb26005ca9a926f7b59eede15dab4ad42823662"
aws cloudformation create-stack --stack-name hri-MAIN --template-body file://./hri-MAIN-inspect.yaml --region us-east-1 --profile lab --capabilities CAPABILITY_IAM --parameters ParameterKey="pInspectvMXToken",ParameterValue="${vMXToken}"
