#!/usr/bin/env bash
set -euo pipefail

# Grab the resource object that has a key with the pattern Spoke1 and then sed to Spoke3
# Make unique to not overwrite

FromSpoke=Spoke1
NewSpokeName=SpokeX

[[ -f ../HRI-BIGNETWORK.yaml ]] || {

  echo "Where is the yaml?"
  exit 1
}
# yq -Y ".Resources | with_entries(select(.key | test(\"${FromSpoke}\"))) | .[]" ../HRI-BIGNETWORK.yaml |
#  sed 's/Spoke1/Spoke3/g' >./Spoke3-"$(printf "%05d" $RANDOM).yaml"

yq -Y ".Resources | to_entries | map(select(.key | contains(\"${FromSpoke}\"))) | from_entries" ../HRI-BIGNETWORK.yaml |
  sed "s/Spoke1/${NewSpokeName}/g" >./"${NewSpokeName}-$(printf "%05d" $RANDOM).yaml"
