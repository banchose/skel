#!/usr/bin/env bash

# In the Network Account

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pDevVpcId}" --profile net

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pTestVpcId}" --profile net

# Target accounts

### DEV

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pDevVpcId}" --profile dev

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pDevVpcId}" --profile dev

### TEST

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pTestVpcId}" --profile test

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
  --vpc VPCRegion="${AwsRegion}",VPCId="${pTestVpcId}" --profile test
