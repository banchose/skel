# aws cloudformation create-stack --stack-name eks-nlb \
# --template-body file://./eks-nlb.yaml \
# --parameters ParameterKey="pSubnetIds",ParameterValue="\"${rTestWorkloadPrivateSubnet},${rTestWorkloadPrivateSubnetAZ2}"\" \
# ParameterKey="pVpcId",ParameterValue="${rTestVpc}"  \
# --capabilities CAPABILITY_NAMED_IAM \
# --disable-rollback \
# --region us-east-1 \
# --profile test

# aws eks describe-cluster --name alpha-eks-cluster --query "cluster.endpoint" --output text --profile test
# aws eks describe-cluster --name alpha-eks-cluster --query "cluster.certificateAuthority.data" --output text --profile test
# aws eks describe-cluster --name alpha-eks-cluster --query "cluster.kubernetesNetworkConfig.serviceIpv4Cidr" --output text --profile test

AWSTemplateFormatVersion: "2010-09-09"

Parameters:

  pNodeImageIdSSMParam:
    Type: "AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>"
    Default: "/aws/service/eks/optimized-ami/1.32/amazon-linux-2023/x86_64/standard/recommended/image_id"
    Description: "Fetch the latest Amazon Linux 2023 AMI for EKS worker nodes running Kubernetes 1.32."

  pClusterName:
    Type: String
    Default: alpha-eks-cluster
    Description: "Name of the EKS cluster"

  pVpcId:
    Description: "Provide VPC for the EKS cluster"
    Type: AWS::EC2::VPC::Id

  pSubnetIds:
    Description: "Select at least 2 subnets in different AZs"
    Type: List<AWS::EC2::Subnet::Id>

  pHriAwsCidr:
    Type: String
    Default: 172.22.0.0/16
    Description: "CIDR block for AWS-based SSH access"

  pHriOnPremCidr:
    Type: String
    Default: 10.0.0.0/8
    Description: "CIDR block for on-premises SSH access"

  pKeyName:
    Description: "Key Pair to access Worker Nodes via SSH"
    Type: AWS::EC2::KeyPair::KeyName
    Default: InspectSshKeyPair 

  pNodeInstanceType:
    Description: "Worker Node Instance Type"
    Type: String
    Default: t3.medium

  pApiServerEndpoint:
    Type: String
    Default: "https://7F3CA29FA947084AE077E2CF8A6BE25F.gr7.us-east-1.eks.amazonaws.com"

  pCertificateAuthority:
    Type: String
    Default: long base64 sting

  pServiceCidr:
    Type: String
    Default: 10.100.0.0/16

Resources:

  rEKSCluster:
    Type: AWS::EKS::Cluster
    Properties:
      Name: !Ref pClusterName
      ResourcesVpcConfig:
        SecurityGroupIds:
          - !Ref rControlPlaneSecurityGroup
        SubnetIds: !Ref pSubnetIds
      RoleArn: !GetAtt rEksServiceRole.Arn
      AccessConfig:
        AuthenticationMode: "API_AND_CONFIG_MAP"
      Version: "1.32"  # Hard-coded EKS version

  rEksServiceRole:
    Type: AWS::IAM::Role
    Properties:
      AssumeRolePolicyDocument:
        Version: "2012-10-17"
        Statement:
          - Effect: "Allow"
            Principal:
              Service: "eks.amazonaws.com"
            Action: "sts:AssumeRole"
      Path: "/"
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/AmazonEKSClusterPolicy
        - arn:aws:iam::aws:policy/AmazonEKSServicePolicy
      RoleName: !Sub "EksSvcRole-${pClusterName}"

  rControlPlaneSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: "Cluster communication with worker nodes"
      VpcId: !Ref pVpcId
      Tags:
        - Key: Name
          Value: !Sub "${pClusterName}-ControlPlaneSecurityGroup"

  rControlPlaneIngressFromWorkerNodesHttps:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow incoming HTTPS traffic (TCP/443) from worker nodes (for API server)"
      GroupId: !Ref rControlPlaneSecurityGroup
      SourceSecurityGroupId: !GetAtt rNodeSecurityGroup.GroupId
      IpProtocol: tcp
      ToPort: 443
      FromPort: 443

  rControlPlaneEgressToWorkerNodesKubelet:
    Type: AWS::EC2::SecurityGroupEgress
    Properties:
      Description: "Allow outgoing kubelet traffic (TCP/10250) to worker nodes"
      GroupId: !Ref rControlPlaneSecurityGroup
      DestinationSecurityGroupId: !GetAtt rNodeSecurityGroup.GroupId
      IpProtocol: tcp
      FromPort: 10250
      ToPort: 10250

  rControlPlaneEgressToWorkerNodesHttps:
    Type: AWS::EC2::SecurityGroupEgress
    Properties:
      Description: "Allow outgoing HTTPS traffic (TCP/443) to worker nodes"
      GroupId: !Ref rControlPlaneSecurityGroup
      DestinationSecurityGroupId: !GetAtt rNodeSecurityGroup.GroupId
      IpProtocol: tcp
      FromPort: 443
      ToPort: 443

  rNodeSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: "Security group for all nodes in the cluster"
      VpcId: !Ref pVpcId
      Tags:
        - Key: !Sub "kubernetes.io/cluster/${pClusterName}"
          Value: "owned"
        - Key: Name
          Value: !Sub "${pClusterName}-cluster/NodeSecurityGroup"

  rNodeSecurityGroupIngress:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow node to communicate with each other"
      GroupId: !Ref rNodeSecurityGroup
      SourceSecurityGroupId: !Ref rNodeSecurityGroup
      IpProtocol: '-1'

  rNodeSecurityGroupFromControlPlaneIngress:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow worker Kubelets and pods to receive communication from the cluster control plane"
      GroupId: !Ref rNodeSecurityGroup
      SourceSecurityGroupId: !Ref rControlPlaneSecurityGroup
      IpProtocol: tcp
      FromPort: 10250
      ToPort: 10250

  rNodeSecurityGroupFromControlPlaneOn443Ingress:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow pods running extension API servers on port 443 to receive communication from cluster control plane"
      GroupId: !Ref rNodeSecurityGroup
      SourceSecurityGroupId: !Ref rControlPlaneSecurityGroup
      IpProtocol: tcp
      FromPort: 443
      ToPort: 443

  rNodeSecurityGroupFromSSHOnPremIngress:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow ssh to worker nodes from on-prem"
      GroupId: !Ref rNodeSecurityGroup
      IpProtocol: tcp
      FromPort: 22
      ToPort: 22
      CidrIp: !Ref pHriOnPremCidr

  rNodeSecurityGroupFromSSHAwsIngress:
    Type: AWS::EC2::SecurityGroupIngress
    Properties:
      Description: "Allow ssh to worker nodes from AWS"
      GroupId: !Ref rNodeSecurityGroup
      IpProtocol: tcp
      FromPort: 22
      ToPort: 22
      CidrIp: !Ref pHriAwsCidr

  # rNodeSecurityGroupFromSSHIngress:
  #   Type: AWS::EC2::SecurityGroupIngress
  #   Properties:
  #     Description: "Allow ssh to worker nodes"
  #     GroupId: !Ref rNodeSecurityGroup
  #     IpProtocol: tcp
  #     FromPort: 22
  #     ToPort: 22
  #     CidrIp: 0.0.0.0/0

  rNodeInstanceRole:
    DependsOn: rEKSCluster
    Type: AWS::IAM::Role
    Properties:
      AssumeRolePolicyDocument:
        Version: "2012-10-17"
        Statement:
          - Effect: "Allow"
            Principal:
              Service: "ec2.amazonaws.com"
            Action: "sts:AssumeRole"
      Path: "/"
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy
        - arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy
        - arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly
        - arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore

  rNodeInstanceProfile:
    Type: AWS::IAM::InstanceProfile
    Properties:
      Roles:
        - !Ref rNodeInstanceRole

  rSingleEC2WorkerNode:
    Type: AWS::EC2::Instance
    DependsOn: rEKSCluster
    Properties:
      InstanceType: !Ref pNodeInstanceType
      KeyName: !Ref pKeyName
      ImageId: !Ref pNodeImageIdSSMParam
      IamInstanceProfile: !Ref rNodeInstanceProfile
      SubnetId: !Select [ 0, !Ref pSubnetIds ]
      SecurityGroupIds:
        - !Ref rNodeSecurityGroup
      Tags:
        - Key: Name
          Value: !Sub "${pClusterName}-SingleWorkerNode"
      UserData:
        Fn::Base64: !Sub |
          MIME-Version: 1.0
          Content-Type: multipart/mixed; boundary="==MYBOUNDARY=="
  
          --==MYBOUNDARY==
          Content-Type: application/node.eks.aws
  
          ---
          apiVersion: node.eks.aws/v1alpha1
          kind: NodeConfig
          spec:
            cluster:
              name: ${pClusterName}
              apiServerEndpoint: ${pApiServerEndpoint}
              certificateAuthority: ${pCertificateAuthority}
              cidr: ${pServiceCidr}
  
          --==MYBOUNDARY==--
  
  rInternalNLB:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Scheme: internal
      Type: network
      Subnets: !Ref pSubnetIds
      Tags:
        - Key: Name
          Value: !Sub '${pClusterName}-InternalNLB'
  
  rNLBTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Port: 31000
      Protocol: TCP
      VpcId: !Ref pVpcId
      TargetType: instance
      Targets:
      - Id: !Ref rSingleEC2WorkerNode
        Port: 31000
  
  rNLBListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    Properties:
      DefaultActions:
        - Type: forward
          TargetGroupArn: !Ref rNLBTargetGroup
      LoadBalancerArn: !Ref rInternalNLB
      Port: 80
      Protocol: TCP

Outputs:
  oEKSCluster:
    Value: !Ref rEKSCluster
  oEKSClusterArn:
    Value: !GetAtt rEKSCluster.Arn
  oEKSClusterEndpoint:
    Value: !GetAtt rEKSCluster.Endpoint
  oEKSClusterClusterSg:
    Value: !GetAtt rEKSCluster.ClusterSecurityGroupId
  oSingleEC2WorkerNode:
    Value: !Ref rSingleEC2WorkerNode
  oEksServiceRole:
    Value: !Ref rEksServiceRole
  oEKSClusterOIDC:
    Value: !GetAtt rEKSCluster.OpenIdConnectIssuerUrl
  #   oEKSClusterCertificateAuthorityData:
    #  Value: !GetAtt rEKSCluster.CertificateAuthorityData
  oEKSClusterOIDC:
    Value: !GetAtt rEKSCluster.OpenIdConnectIssuerUrl
  oNLBCanonicalHostedZoneID:
    Value: !GetAtt rInternalNLB.CanonicalHostedZoneID
    Description: "The ID of the Amazon Route 53 hosted zone associated with the load balancer"
  oNLBDNSName:
    Value: !GetAtt rInternalNLB.DNSName
    Description: "The DNS name for the load balancer"
  oNLBLoadBalancerArn:
    Value: !GetAtt rInternalNLB.LoadBalancerArn
    Description: "The Amazon Resource Name (ARN) of the load balancer"
  oNLBLoadBalancerFullName:
    Value: !GetAtt rInternalNLB.LoadBalancerFullName
    Description: "The full name of the load balancer"
  oNLBLoadBalancerName:
    Value: !GetAtt rInternalNLB.LoadBalancerName
    Description: "The name of the load balancer"
  #   oEKSClusterCertificateAuthorityData:
    #  Value: !GetAtt rEKSCluster.CertificateAuthorityData


