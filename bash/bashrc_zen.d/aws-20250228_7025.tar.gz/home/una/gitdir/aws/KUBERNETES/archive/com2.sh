#!/usr/bin/env bash

set -xeuo pipefail

AccountId=405350004483
Profile=test
StackName=eks-nlb

# This modifies the ~/.kube/config and creates a context
aws eks update-kubeconfig --name alpha-eks-cluster --region us-east-1 --profile test
# Run a command in the context
kubectl get pods --context arn:aws:eks:us-east-1:"${AccountId}":cluster/alpha-eks-cluster
# Confirm context
kubectl config current-context
# Set the session context to AWS
kubectl config use-context arn:aws:eks:us-east-1:"${AccountId}":cluster/alpha-eks-cluster
# Confirm context
kubectl config current-context
kubectl get pods -A
kubectl get nodes

#
## Configure aws-auth
#
# 1. Get the IAM Role ARN for the worker nodes
RoleArn="$(
  aws iam get-role \
    --role-name "$(aws cloudformation describe-stack-resources \
      --stack-name "${StackName}" \
      --query "StackResources[?LogicalResourceId=='rNodeInstanceRole'].PhysicalResourceId" \
      --output text \
      --profile "${Profile}")" \
    --query "Role.Arn" \
    --output text \
    --profile "${Profile}"
)"

# Check for empty RoleArn
if [[ -z "${RoleArn}" ]]; then
  echo "ERROR: Failed to retrieve IAM Role ARN for worker nodes."
  exit 1
fi
#
# 2. Cloudformation can't do this
#    without a lambda function
#    Save to file to apply instead

cat <<EOF >aws-auth-cm.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: aws-auth
  namespace: kube-system
data:
  mapRoles: |
    - rolearn: ${RoleArn}
      username: system:node:{{EC2PrivateDNSName}}
      groups:
        - system:bootstrappers
        - system:nodes
EOF

# 3. Apply
kubectl apply -f aws-auth-cm.yaml
