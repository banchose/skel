#!/usr/bin/env bash

sanitize_input() {
  local input="$1"
  local max_length=300 # Define maximum length
  local sanitized

  # Remove non-printable characters except for newline and tab, then truncate
  sanitized=$(echo "$input" | tr -cd '[:print:]\t\n' | cut -c 1-"$max_length")

  # Ensure input hasn't been tampered with
  if [[ "$sanitized" != "$input" ]]; then
    echo "Error: Input contained invalid characters or exceeded length limit." >&2
    return 1
  fi

  echo "$sanitized"
}

# Sanitize the filename
sanitized_filename=$(sanitize_input "$1") || exit 1

# Check if file exists
if [[ ! -f "$sanitized_filename" ]]; then
  echo "Error: File '$sanitized_filename' not found." >&2
  exit 1
fi

# Use jq to strip secure data
yq '.pCertificateAuthority = "<REDACTED>"' "$sanitized_filename"
