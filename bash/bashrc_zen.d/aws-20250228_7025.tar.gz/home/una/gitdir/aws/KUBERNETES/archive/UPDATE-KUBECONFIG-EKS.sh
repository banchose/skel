#!/usr/bin/env bash

# Set variables
CLUSTER_NAME="alpha-eks-cluster"
AWS_REGION="us-east-1"
AWS_PROFILE="test"

# Display environment variables for confirmation
echo "The following environment variables will be used:"
echo "-----------------------------------------------"
echo "CLUSTER_NAME:  $CLUSTER_NAME"
echo "AWS_REGION:    $AWS_REGION"
echo "AWS_PROFILE:   $AWS_PROFILE"
echo "-----------------------------------------------"
echo -n "Type YES to continue: "
read CONFIRMATION

# Check user confirmation
if [[ "$CONFIRMATION" != "YES" ]]; then
  echo "Aborting script. No changes made."
  exit 1
fi

# Update kubeconfig with alias to ensure context name is consistent
aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$AWS_REGION" --profile "$AWS_PROFILE" --alias "$CLUSTER_NAME"

# Switch to the new context directly (since alias ensures consistency)
kubectl config use-context "$CLUSTER_NAME"

echo "Switched to context: $CLUSTER_NAME"
