Account=405350004483
# This modifies the ~/.kube/config and creates a context
aws eks update-kubeconfig --name alpha-eks-cluster --region us-east-1 --profile test
# Run a command in the context
kubectl get pods --context arn:aws:eks:us-east-1:"${AccountId}":cluster/alpha-eks-cluster
# Confirm context
kubectl config current-context
# Set the session context to AWS
kubectl config use-context arn:aws:eks:us-east-1:405350004483:cluster/alpha-eks-cluster
kubectl get pods -A

kubectl get nodes

#
## Configure aws-auth
#

# 1. Get role arn

aws iam get-instance-profile --instance-profile-name eks-nlb-rNodeInstanceProfile-eKsazt7N1tbC \
  --query "InstanceProfile.Roles[].Arn" --output text --profile test

#
# 2. Cloudformation can't do this
#    without a lambda function
#    Save to file to apply instead

cat <<EOF >aws-auth-cm.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: aws-auth
  namespace: kube-system
data:
  mapRoles: |
    - rolearn: arn:aws:iam::405350004483:role/eks-nlb-rNodeInstanceRole-TF0gS7Rgapws
      username: system:node:{{EC2PrivateDNSName}}
      groups:
        - system:bootstrappers
        - system:nodes
EOF

# 3. Apply
kubectl apply -f aws-auth-cm.yaml
