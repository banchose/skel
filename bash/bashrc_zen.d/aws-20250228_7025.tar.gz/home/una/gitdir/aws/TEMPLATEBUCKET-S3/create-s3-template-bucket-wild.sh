#!/usr/bin/env bash
set -xeuo pipefail

Profile=net
BucketName="hri-cloudformation-templates-net-useast1-net"
Template=/home/una/aws/HRIBIGNETWORK/HRI-BIGNETWORK.yaml
BucketPolicy=/home/una/aws/HRIBIGNETWORK/

# Check if required files exist
[[ -f "${Template}" ]] || {
  echo "Template file not found: ${Template}"
  exit 1
}
[[ -f "${BucketPolicy}" ]] || {
  echo "Policy file not found: bucket-policy.json"
  exit 1
}

# First check if bucket exists and create if it doesn't
aws s3api head-bucket --bucket "${BucketName}" --region us-east-1 --profile "${Profile}" ||
  aws s3api create-bucket \
    --bucket "${BucketName}" \
    --region us-east-1 \
    --profile "${Profile}"

# Then apply bucket policy
aws s3api put-bucket-policy \
  --bucket "${BucketName}" \
  --policy file://${BucketPolicy}" \
  --profile "${Profile}" \
  --region us-east-1

# Finally copy the template
aws s3 cp "${Template}" s3://"${BucketName}"/network/"${Template##*/}" \
  --region us-east-1 \
  --profile "${Profile}"
