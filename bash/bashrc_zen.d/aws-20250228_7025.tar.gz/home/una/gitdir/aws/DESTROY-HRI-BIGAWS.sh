#!/usr/bin/env bash

set -euo pipefail

echo "Deleting Transit Gateway Associations"
aws cloudformation delete-stack --stack-name HRI-BIGNETWORK-TGWRT-ASSC-TEST --region us-east-1 --profile net
aws cloudformation delete-stack --stack-name HRI-BIGNETWORK-TGWRT-ASSC-DEV --region us-east-1 --profile net
sleep 2
echo "Deleting DEV DNS Forwarding rule association - FRD"
aws cloudformation delete-stack --stack-name HRI-BIGDEV-FRD-RR-DNS --region us-east-1 --profile dev
sleep 2
echo "Deleting TEST RR FRD"
aws cloudformation delete-stack --stack-name HRI-BIGTEST-FRD-RR-DNS --region us-east-1 --profile test
sleep 2
echo "Deleting BIGTEST"
aws cloudformation delete-stack --stack-name HRI-BIGTEST --region us-east-1 --profile test
sleep 2
echo "Deleting BIGDEV"
aws cloudformation delete-stack --stack-name HRI-BIGDEV --region us-east-1 --profile dev
sleep 10
echo "Deleting BIGAWSDNS"
sleep 10
aws cloudformation delete-stack --stack-name HRI-BIGAWSDNS --region us-east-1 --profile net
sleep 10
echo "Deleting BIGNETWORK"
aws cloudformation delete-stack --stack-name HRI-BIGNETWORK --region us-east-1 --profile net
