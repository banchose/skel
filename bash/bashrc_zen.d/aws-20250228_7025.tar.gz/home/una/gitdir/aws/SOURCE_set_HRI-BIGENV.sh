echo "Setting ENVs for HRI-BIGNETWORK"
set_stack_outputs HRI-BIGNETWORK us-east-1 net
echo "Setting ENVs for HRI-BIGAWSDNS"
set_stack_outputs HRI-BIGAWSDNS us-east-1 net
echo "Setting ENVs for HRI-BIGDEV"
set_stack_outputs HRI-BIGDEV us-east-1 dev
echo "Setting ENVs for HRI-BIGTEST"
set_stack_outputs HRI-BIGTEST us-east-1 test
