aws iam create-role --role-name RDS-S3-Restore-Role \
  --profile production \
  --region us-east-1 \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Principal": { "Service": "rds.amazonaws.com" },
        "Action": "sts:AssumeRole"
      }
    ]
  }'
