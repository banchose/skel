#!/usr/bin/env bash

set -euo pipefail

# aws s3 rm s3://my-test-war-bucket --recursive
