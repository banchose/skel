#!/usr/bin/env bash

set -euo pipefail

aws s3 cp ./warehouse.war s3://405350004483-my-test-war-bucket/warehouse.war \
  --region us-east-1 \
  --profile test
