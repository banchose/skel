aws ec2 modify-snapshot-attribute --snapshot-id snap-0e58ea8aec2170ab9 \
  --attribute createVolumePermission --operation-type add \
  --user-ids 265444910489 \
  --region us-east-1 \
  --profile lab3
