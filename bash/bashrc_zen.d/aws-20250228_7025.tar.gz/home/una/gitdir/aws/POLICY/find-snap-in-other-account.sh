aws ec2 describe-snapshots --owner-id 217427786773 --region us-east-1 --profile lab3
