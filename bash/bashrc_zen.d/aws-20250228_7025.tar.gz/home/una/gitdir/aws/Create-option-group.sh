aws rds create-option-group \
  --option-group-name sqlserver-backup-restore-group \
  --engine-name sqlserver-se \
  --major-engine-version 16.00 \
  --option-group-description "Option group for enabling SQL Server backup and restore" \
  --profile production \
  --region us-east-1

# aws rds add-option-to-option-group \
#   --option-group-name sqlserver-backup-restore-group \
#   --options SQLSERVER_BACKUP_RESTORE \
#   --apply-immediately \
#   --profile production \
#   --region us-east-1
