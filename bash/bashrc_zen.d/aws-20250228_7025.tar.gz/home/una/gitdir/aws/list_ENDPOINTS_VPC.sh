#!/usr/bin/env bash

get_all_endpoints() {
  local aws_profile="$1"
  local aws_region="${2:-us-east-1}"
  local next_token=""
  local endpoints_json="[]"

  # Add error checking for required parameters
  if [[ -z "$aws_profile" ]]; then
    echo "Error: AWS profile is required" >&2
    return 1
  fi

  while true; do
    local cmd_output
    local aws_command="aws ec2 describe-vpc-endpoints --output json"

    # Add required parameters
    aws_command+=" --region ${aws_region}"
    aws_command+=" --profile ${aws_profile}"

    # Add next-token if present
    if [[ -n "$next_token" ]]; then
      aws_command+=" --starting-token ${next_token}"
    fi

    # Execute AWS command with error checking
    if ! cmd_output=$($aws_command 2>&1); then
      echo "Error executing AWS command: $cmd_output" >&2
      return 1
    fi

    # Debug output
    echo "Raw AWS output:" >&2
    echo "$cmd_output" | jq '.' >&2

    # Get current batch of endpoints
    local current_batch
    current_batch=$(echo "$cmd_output" | jq -r '.VpcEndpoints // []')

    # Debug current batch
    echo "Current batch:" >&2
    echo "$current_batch" | jq '.' >&2

    # Merge with existing results
    endpoints_json=$(echo "[$endpoints_json,$current_batch]" | jq -c 'flatten')

    # Check for next token
    next_token=$(echo "$cmd_output" | jq -r '.NextToken // empty')
    if [[ -z "$next_token" ]]; then
      break
    fi
  done

  # Final output
  echo "$endpoints_json"
}

# Example usage with error handling
if ! output=$(get_all_endpoints "$1" "$2"); then
  echo "Error getting endpoints: $output" >&2
  exit 1
fi

# Pretty print the results
echo "$output" | jq '.'
