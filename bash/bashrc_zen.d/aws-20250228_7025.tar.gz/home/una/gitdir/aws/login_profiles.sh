#!/usr/bin/env bash

get_input() {
  local prompt="$1"
  local regex="$2"
  local input

  while true; do
    read -r -p "$prompt" input
    # Check against the regex if provided
    if [[ -n "$regex" && ! "$input" =~ $regex ]]; then
      echo "Invalid input. Please try again."
    else
      # Escape special characters to prevent injection
      input=$(printf '%q' "$input")
      echo "$input"
      return
    fi
  done
}

echo "#############################################"
echo "Login to LAB"
echo "#############################################"
aws configure sso --profile lab
echo "#############################################"
echo "Login to NET"
echo "#############################################"
aws configure sso --profile net
echo "#############################################"
echo "Login to DEV"
echo "#############################################"
aws configure sso --profile dev
echo "#############################################"
echo "Login to TEST"
echo "#############################################"
aws configure sso --profile test
echo "#############################################"
echo "Login to Production"
echo "#############################################"
aws configure sso --profile production

echo "#############################################"
echo "LAB VPCs"
echo "#############################################"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile lab
aws sts get-caller-identity --region us-east-1 --profile lab
echo "#############################################"
echo "NET VPCs"
echo "#############################################"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile net
aws sts get-caller-identity --region us-east-1 --profile net
echo "#############################################"
echo "DEV VPCs"
echo "#############################################"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile dev
aws sts get-caller-identity --region us-east-1 --profile dev
echo "#############################################"
echo "TEST VPCs"
echo "#############################################"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile test
aws sts get-caller-identity --region us-east-1 --profile test
echo "#############################################"
echo "PRODUCTION VPC"
echo "#############################################"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile production
aws sts get-caller-identity --region us-east-1 --profile production
