aws rds add-role-to-db-instance \
  --profile production \
  --region us-east-1 \
  --db-instance-identifier sqlserver2022-instance \
  --role-arn arn:aws:iam::315633532929:role/RDS-S3-Restore-Role \
  --feature-name S3_INTEGRATION
