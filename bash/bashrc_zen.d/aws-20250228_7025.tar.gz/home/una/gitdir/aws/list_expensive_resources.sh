check_resources() {
  local profile region
  profile=$(get_aws_context "$@")
  region=us-east-1

  printf "\n=== AWS Resource Check for Profile: %s, Region: %s ===\n\n" "$profile" "$region"

  echo "📊 EC2 Instances (Stopped):"
  aws ec2 describe-instances \
    --region "$region" \
    --profile "$profile" \
    --query 'Reservations[*].Instances[?State.Name==`stopped`].[InstanceId,Tags[?Key==`Name`].Value|[0],InstanceType,LaunchTime]' \
    --output table || echo "No stopped instances found"

  echo -e "\n🌐 Unassociated Elastic IPs:"
  aws ec2 describe-addresses \
    --region "$region" \
    --profile "$profile" \
    --query 'Addresses[?AssociationId==null].[PublicIp,AllocationId,Domain]' \
    --output table || echo "No unassociated Elastic IPs found"

  echo -e "\n🚇 Transit Gateways:"
  aws ec2 describe-transit-gateways \
    --region "$region" \
    --profile "$profile" \
    --query 'TransitGateways[*].[TransitGatewayId,State,Description,Tags[?Key==`Name`].Value|[0]]' \
    --output table || echo "No transit gateways found"

  echo -e "\n🔌 VPC Endpoints In Use:"
  aws ec2 describe-vpc-endpoints \
    --region "$region" \
    --profile "$profile" \
    --query 'VpcEndpoints[*].[VpcEndpointId,ServiceName,VpcId,State,Tags[?Key==`Name`].Value|[0]]' \
    --output table || echo "No VPC endpoints found"

  echo -e "\n💲 Interface Endpoint Costs ($.01/hr per AZ):"
  aws ec2 describe-vpc-endpoints \
    --region "$region" \
    --profile "$profile" \
    --query 'VpcEndpoints[?VpcEndpointType==`Interface`].[VpcEndpointId,ServiceName,State]' \
    --output table || echo "No interface endpoints found"

  echo -e "\n💾 Unattached EBS Volumes:"
  aws ec2 describe-volumes \
    --region "$region" \
    --profile "$profile" \
    --filters "Name=status,Values=available" \
    --query 'Volumes[*].[VolumeId,Size,State,CreateTime]' \
    --output table || echo "No unattached volumes found"

  echo -e "\n🌐 NAT Gateways:"
  aws ec2 describe-nat-gateways \
    --region "$region" \
    --profile "$profile" \
    --query 'NatGateways[*].[NatGatewayId,State,VpcId]' \
    --output table || echo "No NAT gateways found"

  echo -e "\n⚖️ Load Balancers:"
  aws elbv2 describe-load-balancers \
    --region "$region" \
    --profile "$profile" \
    --query 'LoadBalancers[*].[LoadBalancerName,DNSName,Type,State.Code]' \
    --output table || echo "No load balancers found"

  echo -e "\n🗄️ RDS Instances:"
  aws rds describe-db-instances \
    --region "$region" \
    --profile "$profile" \
    --query 'DBInstances[*].[DBInstanceIdentifier,Engine,DBInstanceClass,DBInstanceStatus]' \
    --output table || echo "No RDS instances found"

  echo -e "\n🔗 Transit Gateway Attachments:"
  aws ec2 describe-transit-gateway-attachments \
    --region "$region" \
    --profile "$profile" \
    --query 'TransitGatewayAttachments[*].[TransitGatewayAttachmentId,ResourceId,ResourceType,State]' \
    --output table || echo "No transit gateway attachments found"

  echo -e "\n🔄 Route53 Resolver Endpoints:"
  aws route53resolver list-resolver-endpoints \
    --region "$region" \
    --profile "$profile" \
    --query 'ResolverEndpoints[*].[Id,Name,Direction,Status]' \
    --output table || echo "No Route53 resolver endpoints found"

  echo -e "\n🔄 Route53 VPC Endpoints:"
  aws ec2 describe-vpc-endpoints \
    --region "$region" \
    --profile "$profile" \
    --query 'VpcEndpoints[?contains(ServiceName, `route53`)].[VpcEndpointId,ServiceName,VpcEndpointType,State]' \
    --output table || echo "No Route53 VPC endpoints found"

  echo -e "\n📦 S3 Gateway Endpoints:"
  aws ec2 describe-vpc-endpoints \
    --region "$region" \
    --profile "$profile" \
    --query 'VpcEndpoints[?ServiceName==`com.amazonaws.'$region'.s3` && VpcEndpointType==`Gateway`].[VpcEndpointId,ServiceName,State,VpcId]' \
    --output table || echo "No S3 gateway endpoints found"

  echo -e "\n💰 Estimated Monthly Costs:"
  aws ce get-cost-forecast \
    --time-period Start=$(date +%Y-%m-01),End=$(date -d "next month" +%Y-%m-01) \
    --metric UNBLENDED_COST \
    --granularity MONTHLY \
    --region "$region" \
    --profile "$profile" \
    --query 'Total.Amount' \
    --output text 2>/dev/null || echo "Cost estimation not available"

  echo -e "\n⚠️ Cost Attention Items:"
  echo "- Unassociated Elastic IPs (charged when not in use)"
  echo "- Running NAT Gateways ($0.045 per hour + data processing)"
  echo "- Transit Gateways ($0.05 per attachment hour)"
  echo "- VPC Endpoints ($0.01 per AZ hour)"

  echo -e "\n=== End of Resource Check ===\n"
}
