#!/usr/bin/env bash

set -euo pipefail

## Set vMX key or there will be tears
pInspectvMXToken="df4c4d60ec6ba452f414896a250bfe50/a99425ace401a0747ac19391437f6e61945b8014407925db2499c5936b97f3c18ea1f60a5d6ae55baa047c7e5c422cc6b85fdeaa8bcdaee623963df3fba96695/dc1b55b018a6a363b9daec509f39ae5f63aa2b3cd7796e1b387c07276066636a"
# Duplicate from set from a file containing helpful aws bas functions
# Needed to make sure set_stack_outputs was available so it is here 'inline'
set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGNETWORK"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK \
  --template-body file://./HRI-BIGNETWORK.yaml \
  --region us-east-1 \
  --capabilities CAPABILITY_IAM \
  --parameters ParameterKey="pInspectvMXToken",ParameterValue="${pInspectvMXToken}" \
  --profile net

hang_fire HRI-BIGNETWORK net

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGAWSDNS"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack --stack-name HRI-BIGAWSDNS \
  --template-body file://./HRI-BIGAWSDNS.yaml \
  --parameters ParameterKey=pInspectTransitPrivateSubnetId,ParameterValue="${rInspectTransitPrivateSubnet}" \
  ParameterKey=pInspectVpcId,ParameterValue="${rInspectVpc}" \
  ParameterKey=pSpoke1VpcId,ParameterValue="${rSpoke1Vpc}" \
  ParameterKey=pServiceVpcId,ParameterValue="${rServiceVpc}" \
  ParameterKey=pServiceTransitPrivateSubnetId,ParameterValue="${rServiceTransitPrivateSubnet}" \
  ParameterKey=pServiceDataPrivateSubnetId,ParameterValue="${rServiceDataPrivateSubnet}" \
  --region us-east-1 \
  --profile net # net

hang_fire HRI-BIGAWSDNS net # HRI-BIGNETWORK

## HRI-BIGDEV

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGDEV"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGDEV \
  --capabilities CAPABILITY_NAMED_IAM \
  --template-body file://./HRI-BIGDEV.yaml \
  --parameter ParameterKey="pInspectTransitGatewayId",ParameterValue="${rInspectTransitGateway}" \
  --region us-east-1 \
  --profile dev # dev

hang_fire HRI-BIGDEV dev # HRI-BIGDEV

## Next: HRI-BIGNETWORK-TGWRT-ASSC-DEV.yaml

echo ""
echo "***********************************"
echo ""
echo " Transit Gateway association DEV"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-TGWRT-ASSC-DEV \
  --template-body file://./HRI-BIGNETWORK-TGWRT-ASSC-DEV.yaml \
  --parameters ParameterKey="pDevTransitGatewayAttachmentId",ParameterValue="${rDevTransitVpcAttachment}" \
  ParameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${rInspectTransitGatewayRouteTable}" \
  --region us-east-1 \
  --profile net

hang_fire HRI-BIGNETWORK-TGWRT-ASSC-DEV net

echo ""
echo "***********************************"
echo ""
echo " Forwarder Resource Rule DEV"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGDEV-FRD-RR-DNS \
  --template-body file://./HRI-BIGDEV-FRD-RR-DNS.yaml \
  --parameter ParameterKey="pDevVpcId",ParameterValue="${rDevVpcId}" \
  ParameterKey="pDevWorkloadPrivateSubnetId",ParameterValue="${rDevWorkloadPrivateSubnet}" \
  ParameterKey="pDevTransitPrivateSubnetId",ParameterValue="${rDevTransitPrivateSubnet}" \
  ParameterKey="pSharedResolverRuleForwardId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDns}" \
  ParameterKey="pSharedResolverRuleReverseId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDnsRev}" \
  --region us-east-1 \
  --profile dev

hang_fire HRI-BIGDEV-FRD-RR-DNS dev

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGTEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGTEST \
  --capabilities CAPABILITY_NAMED_IAM \
  --template-body file://./HRI-BIGTEST.yaml \
  --parameter ParameterKey="pInspectTransitGatewayId",ParameterValue="${rInspectTransitGateway}" \
  --region us-east-1 \
  --profile test

hang_fire HRI-BIGTEST test

# set_stack_outputs HRI-BIGNETWORK us-east-1 net
# set_stack_outputs HRI-BIGAWSDNS us-east-1 net
# set_stack_outputs HRI-BIGDEV us-east-1 dev
# set_stack_outputs HRI-BIGTEST us-east-1 test

echo ""
echo "***********************************"
echo ""
echo " Forwarder Resource Rule TEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGTEST-FRD-RR-DNS \
  --template-body file://./HRI-BIGTEST-FRD-RR-DNS.yaml \
  --parameter ParameterKey="pTestVpcId",ParameterValue="${rTestVpc}" \
  ParameterKey="pTestWorkloadPrivateSubnetId",ParameterValue="${rTestWorkloadPrivateSubnet}" \
  ParameterKey="pTestTransitPrivateSubnetId",ParameterValue="${rTestTransitPrivateSubnet}" \
  ParameterKey="pSharedResolverRuleForwardId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDns}" \
  ParameterKey="pSharedResolverRuleReverseId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDnsRev}" \
  --region us-east-1 \
  --profile test

hang_fire HRI-BIGTEST-FRD-RR-DNS test

echo ""
echo "***********************************"
echo ""
echo " Transit Gateway association TEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-TGWRT-ASSC-TEST \
  --template-body file://./HRI-BIGNETWORK-TGWRT-ASSC-TEST.yaml \
  --parameters ParameterKey="pTestTransitGatewayAttachmentId",ParameterValue="${rTestTransitVpcAttachment}" \
  ParameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${rInspectTransitGatewayRouteTable}" \
  --region us-east-1 \
  --profile net

hang_fire HRI-BIGNETWORK-TGWRT-ASSC-TEST net

echo "Doing the Private Hosted Zone associations with DEV and TEST"

echo ""
echo "***********************************"
echo ""
echo " Associating Hosted Zone with DEV"
echo ""
echo "***********************************"
echo ""

./HRI-BIGDEV-ASSC-HOSTZONE-DEV.sh

echo ""
echo "***********************************"
echo ""
echo " Associating Hosted Zone with TEST"
echo ""
echo "***********************************"
echo ""

./HRI-BIGTEST-ASSC-HOSTZONE-TEST.sh

echo ""
echo "********** NOTE **********"
echo ""
echo ""
echo "     Remember to update the IP addresses on the HRI AD DNS"
echo "     2 forward aws.healthresearch.org, rds.amazonaws.com"
echo "     1 reverse zones on the Active Directory DNS"
echo ""
echo ""
echo "**************************"
