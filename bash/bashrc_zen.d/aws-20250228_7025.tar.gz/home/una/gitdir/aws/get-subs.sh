#!/usr/bin/env bash

set -euo pipefail

AwsProfile="net"
AwsRegion="us-east-1"

# Fetch all subnets in the account and region
echo "Listing all subnets in region ${AwsRegion} for profile ${AwsProfile}:"
aws ec2 describe-subnets --region "${AwsRegion}" --profile "${AwsProfile}" \
  --query 'Subnets[*].{SubnetId:SubnetId, CidrBlock:CidrBlock, VpcId:VpcId, AvailabilityZone:AvailabilityZone, Name:Tags[?Key==`Name`].Value | [0]}' \
  --output table
