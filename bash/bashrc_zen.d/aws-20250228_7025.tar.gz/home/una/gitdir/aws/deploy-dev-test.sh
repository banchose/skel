#!/usr/bin/env bash

set -o pipefail

pInspectTransitGatewayId="tgw-055c0446a18612834"
pHriAwsPrivateHostedZoneId="Z01797003KZSVDTTKESR6"
pHriAwsPrivateHostedZoneIdRev="Z0179681YXT21PB0BHXS"
pInspectTransitGatewayRouteTableId="tgw-rtb-0eb86530f01775bb4"
pDevTransitGatewayAttachmentId="tgw-attach-07230c89f1f0b0fd9"
pInspectFirewallSubnetId=subnet-03bb9467a93faaf56
pInspectTransitGatewaySubnetId=subnet-01b6cfa298e04223d
# pDevVpcId="vpc-0d8d2e2799ce24755"
# pTestVpcId="vpc-0cfde41e18091467e"
pSpoke1VpcId=vpc-0366b7aa344c780c2
pSpoke2VpcId=vpc-0e7dc8e74f5691dec
pInspectVpcId=vpc-095b47d7d299cb6a5
# pTestTransitGatewayAttachmentId=
# pInspectvMXToken=
Region=us-east-1

# Create Network

# aws cloudformation create-stack \
#   --stack-name HRI-BIGNETWORK \
#   --template-body file://./HRI-BIGNETWORK.yaml \
#   --capabilities CAPABILITY_IAM \
#   --parameters ParameterKey="pInspectvMXToken",ParameterValue="f98291188bdd6df6301041cc62abf716/4e6f3671ea4257703c746f17545eb90176bc604786eda4a38d8005643053c21cee04c21d617332a823c74279a9f48462a79826da0324f5757e607beb66526bb3/cda235ed58889f94ceb53d119d2bacc427af4ac45bc8b7a18a65eb86777a34eb" \
#   --region "${Region}" \
#   --profile net
#
# # Create Dev
#
# aws cloudformation create-stack \
#   --stack-name HRI-DEV --template-body file:///home/una/gitdir/aws/HRI-BIGDEV.yaml \
#   --capabilities CAPABILITY_NAMED_IAM \
#   --parameters ParameterKey="pInspectTransitGatewayId",ParameterValue="${pInspectTransitGatewayId}" \
#   --region "${Region}" \
#   --profile dev
#
# # Create Test
#
# aws cloudformation create-stack \
#   --stack-name HRI-TEST --template-body file://./HRI-TEST.yaml \
#   --capabilities CAPABILITY_NAMED_IAM \
#   --parameters ParameterKey="pInspectTransitGatewayId",ParameterValue="${pInspectTransitGatewayId" \
#   --region "${Region}" \
#   --profile test
#
# ## Associate - in net account
#
# aws cloudformation create-stack \
#   --stack-name HRI-BIGNETWORK-ASSOC-DEV \
#   --template-body file:///home/una/gitdir/aws/HRI-BIGNETWORK-ASSC-DEV.yaml \
#   --parameters ParameterKey="pDevTransitGatewayAttachmentId",ParameterValue="${pDevTransitGatewayAttachmentId}" \
#   ParameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${pInspectTransitGatewayRouteTableId}" \
#   --region "${Region}" \
#   --profile net # yes net!
#
# aws cloudformation create-stack \
#   --stack-name HRI-BIGNETWORK-ASSOC-TEST \
#   --template-body file://HRI-BIGNETWORK-ASSC-TEST.yaml \
#   --parameters ParameterKey="pTestTransitGatewayAttachmentId",ParameterValue="${pTestTransitGatewayAttachmentId}" \
#   ParatameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${pInspectTransitGatewayRouteTableId}" \
#   --region "${Region}" \
#   --profile net # yes net!

# Create HRI AWS Private Hosted Zone route53

# aws cloudformation create-stack --stack-name HRI-BIGAWSDNS --template-body file://./HRI-BIGAWS
# aws cloudformation create-change-set --change-set-name Add-Rev-Zone --stack-name HRI-BIGAWSDNS
#
# # Create the CloudFormation stack
aws cloudformation create-stack \
  --stack-name HRI-BIGAWSDNS \
  --template-body file:///home/una/gitdir/aws/HRI-BIGAWSDNS.yaml \
  --parameters ParameterKey=pInspectTransitGatewaySubnetId,ParameterValue="${pInspectTransitGatewaySubnetId}" \
  ParameterKey=pInspectVpcId,ParameterValue="${pInspectVpcId}" \
  ParameterKey=pSpoke1VpcId,ParameterValue="${pSpoke1VpcId}" \
  ParameterKey=pSpoke2VpcId,ParameterValue="${pSpoke2VpcId}" \
  ParameterKey=pInspectFirewallSubnetId,ParameterValue="${pInspectFirewallSubnetId}" \
  ParameterKey=pInspectTransitGatewaySubnetId,ParameterValue="${pInspectFirewallSubnetId}" \
  --region us-east-1 \
  --profile net

# Create a change set
# aws cloudformation create-change-set \
#   --change-set-name Add-Rev-Zone \
#   --stack-name HRI-BIGAWSDNS \
#   --template-body file://HRI-BIGAWSDNS.yaml \
#   --parameters ParameterKey=pInspectTransitGatewaySubnetId,ParameterValue="${pInspectTransitGatewaySubnetId}" \
#   ParameterKey=pInspectVpcId,ParameterValue="${pInspectVpcId}" \
#   ParameterKey=pSpoke1VpcId,ParameterValue="${pSpoke1VpcId}" \
#   ParameterKey=pSpoke2VpcId,ParameterValue="${pSpoke2VpcId}" \
#   ParameterKey=pInspectFirewallSubnetId,ParameterValue="${pInspectFirewallSubnetId}" \
#   --region us-east-1 \
#   --profile net

## Auth Associate

### In HRI-BIGNETWORK

#### Forward zone in NETWORK for Dev

# aws route53 create-vpc-association-authorization \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
#   --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile net
#
# #### Forward zone in NETWORK for Test
#
# aws route53 create-vpc-association-authorization \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
#   --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile net
#
# #### Reverse Zone NETWORK for Dev
#
# aws route53 create-vpc-association-authorization \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
#   --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile net
#
# #### Reverse Zone NETWORK for Test
#
# aws route53 create-vpc-association-authorization \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
#   --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile net
#
# ### In the Accounts
#
# #### Development
#
# aws route53 associate-vpc-with-hosted-zone \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
#   --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile dev
#
# aws route53 associate-vpc-with-hosted-zone \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
#   --vpc VPCRegion="${Region}",VPCId="${pDevVpcId}" --profile dev
#
# #### Test
#
# aws route53 associate-vpc-with-hosted-zone \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
#   --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile test
#
# aws route53 associate-vpc-with-hosted-zone \
#   --hosted-zone-id "${pHriAwsPrivateHostedZoneIdRev}" \
#   --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" --profile test
#
######################################### Delete

# From NETWORK

# aws route53 delete-vpc-association-authorization \
# --hosted-zone-id "${pHriAwsPrivateHostedZoneId}" \
# --vpc VPCRegion="${Region}",VPCId="${pTestVpcId}" \
# --profile xyz
#
#
