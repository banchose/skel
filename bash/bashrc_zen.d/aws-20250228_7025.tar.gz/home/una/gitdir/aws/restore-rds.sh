exec msdb.dbo.rds_restore_database
@restore_db_name='TEST2_pi_salary_recovery',
@s3_arn_to_restore_from='arn:aws:s3:::hri-my-access-gateway-bucket/QA_pi_salary_recovery.bak'
