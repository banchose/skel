# Compare source IPs in logs from both AZs (replace IP range with your subnet)
aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/flow" \
  --filter-pattern "{$.event.src_ip = 172.22.*}" \
  --limit 10 \
  --region us-east-1 \
  --profile net

aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/flow-AZB" \
  --filter-pattern "{$.event.src_ip = 172.22.*}" \
  --limit 10 \
  --region us-east-1 \
  --profile net
# Check for dropped packets in AZ-A alert logs
aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/alert" \
  --filter-pattern "{$.event.flow.action = \"blocked\"}" \
  --limit 10 \
  --region us-east-1 \
  --profile net

# Same for AZ-B
aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/alert-AZB" \
  --filter-pattern "{$.event.flow.action = \"blocked\"}" \
  --limit 10 \
  --region us-east-1 \
  --profile net

# To see traffic heading to the internet through NAT in AZ-A
aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/flow" \
  --filter-pattern "{$.event.dest_ip NOT = 10.* && $.event.dest_ip NOT = 172.* && $.event.dest_ip NOT = 192.168.*}" \
  --limit 10 \
  --region us-east-1 \
  --profile net

# To see traffic heading to on-premises (assuming 10.x.x.x is your on-prem range)
aws logs filter-log-events \
  --log-group-name "/network-stack/anfw/flow-AZB" \
  --filter-pattern "{$.event.dest_ip = 10.*}" \
  --limit 10 \
  --region us-east-1 \
  --profile net

aws logs put-metric-filter \
  --log-group-name "/network-stack/anfw/flow" \
  --filter-name "TrafficVolume" \
  --filter-pattern "{$.event.netflow.bytes > 0}" \
  --metric-transformations \
  metricName=FirewallTrafficVolume,metricNamespace=NetworkFirewall,metricValue=$.event.netflow.bytes \
  --region us-east-1 \
  --profile net
