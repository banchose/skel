#!/bin/bash

# AWS Network Information Script - Simplified
# Gets raw AWS network information with minimal filtering

# Default values
AWS_REGION="us-east-1"
AWS_PROFILE="default"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -r|--region)
            AWS_REGION="$2"
            shift 2
            ;;
        -p|--profile)
            AWS_PROFILE="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo "Options:"
            echo "  -r, --region REGION    AWS region (default: us-east-1)"
            echo "  -p, --profile PROFILE  AWS profile (default: default)"
            echo "  -h, --help             Display this help message"
            exit 1
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Set region and profile parameters
REGION_PARAM="--region $AWS_REGION"
PROFILE_PARAM="--profile $AWS_PROFILE"

echo "AWS NETWORK INFORMATION - REGION: $AWS_REGION, PROFILE: $AWS_PROFILE"
echo "================================================================="

# Create output directory
OUTPUT_DIR="./aws-network-info"
mkdir -p "$OUTPUT_DIR"

# Function to get VPC information
get_vpc_info() {
    echo "Fetching VPC information..."
    aws ec2 describe-vpcs $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/vpcs.json"
}

# Function to get subnet information
get_subnet_info() {
    echo "Fetching subnet information..."
    aws ec2 describe-subnets $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/subnets.json"
}

# Function to get route table information
get_route_table_info() {
    echo "Fetching route table information..."
    aws ec2 describe-route-tables $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/route_tables.json"
}

# Function to get security group information
get_security_group_info() {
    echo "Fetching security group information..."
    aws ec2 describe-security-groups $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/security_groups.json"
}

# Function to get Network Firewall information
get_network_firewall_info() {
    echo "Fetching Network Firewall information..."
    aws network-firewall list-firewalls $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/network_firewalls_list.json"
    
    # Get detailed information for each firewall
    firewall_arns=$(jq -r '.Firewalls[].FirewallArn' "$OUTPUT_DIR/network_firewalls_list.json" 2>/dev/null || echo "")
    if [ -n "$firewall_arns" ]; then
        mkdir -p "$OUTPUT_DIR/firewalls"
        for arn in $firewall_arns; do
            firewall_name=$(basename "$arn")
            aws network-firewall describe-firewall $REGION_PARAM $PROFILE_PARAM --firewall-arn "$arn" --output json > "$OUTPUT_DIR/firewalls/$firewall_name.json"
        done
    fi
}

# Function to get Transit Gateway information
get_transit_gateway_info() {
    echo "Fetching Transit Gateway information..."
    aws ec2 describe-transit-gateways $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/transit_gateways.json"
    
    # Get Transit Gateway attachments
    echo "Fetching Transit Gateway attachments..."
    aws ec2 describe-transit-gateway-attachments $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/transit_gateway_attachments.json"
    
    # Get Transit Gateway route tables
    echo "Fetching Transit Gateway route tables..."
    aws ec2 describe-transit-gateway-route-tables $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/transit_gateway_route_tables.json"
    
    # Get routes for each Transit Gateway route table
    tgw_rt_ids=$(jq -r '.TransitGatewayRouteTables[].TransitGatewayRouteTableId' "$OUTPUT_DIR/transit_gateway_route_tables.json" 2>/dev/null || echo "")
    if [ -n "$tgw_rt_ids" ]; then
        mkdir -p "$OUTPUT_DIR/tgw_routes"
        for rt_id in $tgw_rt_ids; do
            echo "Fetching routes for Transit Gateway route table $rt_id..."
            aws ec2 search-transit-gateway-routes $REGION_PARAM $PROFILE_PARAM \
                --transit-gateway-route-table-id "$rt_id" \
                --filters "Name=type,Values=static,propagated" \
                --output json > "$OUTPUT_DIR/tgw_routes/$rt_id.json" 2>/dev/null || echo "{\"Routes\": []}" > "$OUTPUT_DIR/tgw_routes/$rt_id.json"
        done
    fi
}

# Function to get NAT Gateway information
get_nat_gateway_info() {
    echo "Fetching NAT Gateway information..."
    aws ec2 describe-nat-gateways $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/nat_gateways.json"
}

# Function to get Internet Gateway information
get_internet_gateway_info() {
    echo "Fetching Internet Gateway information..."
    aws ec2 describe-internet-gateways $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/internet_gateways.json"
}

# Function to get VPC Peering information
get_vpc_peering_info() {
    echo "Fetching VPC Peering information..."
    aws ec2 describe-vpc-peering-connections $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/vpc_peering.json"
}

# Function to get Network ACL information
get_network_acl_info() {
    echo "Fetching Network ACL information..."
    aws ec2 describe-network-acls $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/network_acls.json"
}

# Function to get VPC Endpoint information
get_vpc_endpoint_info() {
    echo "Fetching VPC Endpoint information..."
    aws ec2 describe-vpc-endpoints $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/vpc_endpoints.json"
}

# Function to get Route53 Resolver information
get_route53_resolver_info() {
    echo "Fetching Route53 Resolver information..."
    aws route53resolver describe-resolver-endpoints $REGION_PARAM $PROFILE_PARAM --output json > "$OUTPUT_DIR/route53_resolver_endpoints.json" 2>/dev/null || echo "{\"ResolverEndpoints\": []}" > "$OUTPUT_DIR/route53_resolver_endpoints.json"
}

# Main execution
echo "Starting AWS network summary collection..."

# Check if AWS CLI is configured with the specified profile
if ! aws configure list --profile "$AWS_PROFILE" &>/dev/null; then
    echo "Warning: AWS profile '$AWS_PROFILE' not found. Using default credentials."
    AWS_PROFILE="default"
fi

# Execute the information gathering functions with error handling
run_with_error_handling() {
    local func_name="$1"
    echo "Running $func_name..."
    if $func_name; then
        echo "$func_name completed successfully."
    else
        echo "Warning: $func_name encountered errors. Continuing with partial data."
    fi
    echo ""
}

run_with_error_handling get_vpc_info
run_with_error_handling get_subnet_info
run_with_error_handling get_route_table_info
run_with_error_handling get_security_group_info
run_with_error_handling get_network_firewall_info
run_with_error_handling get_transit_gateway_info
run_with_error_handling get_nat_gateway_info
run_with_error_handling get_internet_gateway_info
run_with_error_handling get_vpc_peering_info
run_with_error_handling get_network_acl_info
run_with_error_handling get_vpc_endpoint_info
run_with_error_handling get_route53_resolver_info

# Create a combined JSON file with all the data
echo "Creating a combined JSON file with all the data..."
echo "{" > "$OUTPUT_DIR/combined.json"

# Loop through all JSON files in the output directory
first_file=true
for json_file in "$OUTPUT_DIR"/*.json; do
    # Skip the combined.json file itself
    if [ "$json_file" = "$OUTPUT_DIR/combined.json" ]; then
        continue
    fi
    
    # Get the base name without extension to use as the key
    key=$(basename "$json_file" .json)
    
    # Add a comma before all entries except the first one
    if [ "$first_file" = true ]; then
        first_file=false
    else
        echo "," >> "$OUTPUT_DIR/combined.json"
    fi
    
    # Add the file content with its key
    echo "  \"$key\": $(cat "$json_file")" >> "$OUTPUT_DIR/combined.json"
done

# Close the JSON object
echo "}" >> "$OUTPUT_DIR/combined.json"

echo "=============================================================="
echo "AWS Network Information collection completed!"
echo "All network information saved to: $OUTPUT_DIR/"
echo "Combined JSON file: $OUTPUT_DIR/combined.json"
echo "You can now use these JSON files as input for an LLM prompt."
