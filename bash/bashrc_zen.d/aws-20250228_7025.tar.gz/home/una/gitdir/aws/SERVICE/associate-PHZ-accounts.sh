#!/usr/bin/env bash

set -euo pipefail

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  echo "Getting outputs for stack ${stack_name} in ${region} using profile ${profile}"

  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Failed to retrieve stack outputs for '$stack_name'." >&2
    return 1
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using mapfile
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"
    export "$output_key=$output_value"
    echo "Exported $output_key=$output_value"
  done
}

associate_vpc_with_zones() {
  local vpc_id="$1"
  local target_profile="$2"
  local region="${3:-us-east-1}"

  echo "Processing VPC associations for VPC: ${vpc_id}"

  # Create authorizations (from network account)
  aws route53 create-vpc-association-authorization \
    --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
    --vpc "VPCRegion=${region},VPCId=${vpc_id}" \
    --region "${region}" \
    --profile net

  aws route53 create-vpc-association-authorization \
    --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
    --vpc "VPCRegion=${region},VPCId=${vpc_id}" \
    --region "${region}" \
    --profile net

  echo "Waiting 60 seconds for authorization propagation..."
  sleep 60

  # Create associations (from target account)
  aws route53 associate-vpc-with-hosted-zone \
    --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
    --vpc "VPCRegion=${region},VPCId=${vpc_id}" \
    --region "${region}" \
    --profile "${target_profile}"

  aws route53 associate-vpc-with-hosted-zone \
    --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
    --vpc "VPCRegion=${region},VPCId=${vpc_id}" \
    --region "${region}" \
    --profile "${target_profile}"

  echo "VPC associations completed for ${vpc_id}"
}

# Main execution

echo "Starting stack output collection..."

# Get stack outputs
set_stack_outputs "HRI-BIGAWSDNS" "us-east-1" "net"
set_stack_outputs "HRI-BIGDATA" "us-east-1" "production"

echo "Starting VPC associations..."

# Production Data VPC
associate_vpc_with_zones "${rDataVpc}" "production"

# Dev VPC
associate_vpc_with_zones "${rDevVpcId}" "dev"

# Test VPC
associate_vpc_with_zones "${rTestVpc}" "test"

echo "All VPC associations completed successfully"
