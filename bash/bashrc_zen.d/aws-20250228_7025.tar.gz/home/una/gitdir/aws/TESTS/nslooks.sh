#!/usr/bin/env bash

set -euo pipefail

ping -l 1 -c 1 10.1.100.100
ping -l 1 -c 1 10.1.100.101
ping -l 1 -c 1 1.1.1.1

nslookup www.google.com
nslookup www.yahoo.com
nslookup alb-prd-cert-1.corp.healthresearch.org
nslookup alb-prd-print-1.corp.healthresearch.org
nslookup alb-prd-dmas-1.corp.healthresearch.org
nslookup alb-prd-sybase-1.corp.healthresearch.org
nslookup alb-prd-dc-3.corp.healthresearch.org
nslookup alb-prd-dc-4.corp.healthresearch.org
