# AWS Fast

## UserData script does not execute

- Look at the logs of the instance
- If you get an error the whole thing stops

## Can't ping past transit gatway via attachment

- Is you attchement attachet to aljljl

## Launch Template is not working

- Make sure you associated the blah in the network account
