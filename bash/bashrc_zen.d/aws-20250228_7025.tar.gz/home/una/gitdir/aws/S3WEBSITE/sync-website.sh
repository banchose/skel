# ???
return 1

aws s3 sync my-website/ s3://your-bucket-name/
aws s3 cp index.html s3://your-bucket-name/index.html

aws s3 cp my-website.zip s3://your-bucket-name
