# Notes

## Link

<https://docs.aws.amazon.com/AmazonS3/latest/userguide/Welcome.html>
<https://docs.aws.amazon.com/IAM/latest/UserGuide/intro-structure.html#intro-structure-request>

## s3

- s3 - object storage service
- Offers a range of **storage classes**
- Amazon S3 Express One Zone - for latency
- Use IAM-based policy language to configure resource-based permissions

### IAM Policy language

1. **Who** (principal) is allowed or deny access
2. **What** (Actions)
3. **On what resources** (Resources) the permissions apply
4. **Under what conditions** (Conditions)

## Components (IAM Policy)

1. **Version**:

- Specifies the policy language Version

2. **Statement**: "Statement": [ ... ]
3. **Effect**:

## Policy

- A policy is an object in AWS
- Associated with:
  - An identity
  - A resource

### Identitiy-based policies

<https://docs.aws.amazon.com/IAM/latest/UserGuide/tutorial_managed-policies.html>

- UserA can List, Read on Resource X
- Attached to an IAM:
  - user
  - group
  - role

### resource-based policies

- **Resource** X: JohnSmith can List, Read, write
- **Resource Y**: BobStyles allowed full access

### AWS Managed policies

- Standalone policy created by AWS
- Standalone means it has its own arn: `arn:aws:iam:aws:policy/IAMReadOnlyAccess`
- ARN
  - `arn:partition:service:region:account:resource`
    - partition: aws-cn or aws
    - service: identitifies the AWS product like `iam`
    - region: for IAM resources, left **blank** (see `arn:aws:iam::account:root`)
    - account: account id (no hyphens)
    - resource: Identities the resource by name

## ARNs

### Regional endpoints

- `protocol://service-code.region-code.amazonaws.com`

### ARN Format

<https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_identifiers.html#identifiers-arns>

- `arn:partition:service:region:account-id:resource-id`
- `arn:partition:service:region:account-id:resource-type/resource-id`
- `arn:partition:service:region:account-id:resource-type:resource-id`

### Arn examples

- Wildcards: `arn:aws:iam::123456789012:user/Development/product_1234/*`
- NOPE: `arn:aws:iam::123456789012:u*   <== not allowed`
- IAM user: `arn:aws:iam::123456789012:user/johndo`
- VPC: `rn:aws:ec2:us-east-1:123456789012:vpc/vpc-0e9801d129EXAMPLE`
- IAM User group: `arn:aws:iam::123456789012:group/Developers`
- IAM User group with path: `arn:aws:iam::123456789012:group/division_abc/subdivision_xyz/product_A/Developers`
- IAM Role: `arn:aws:iam::123456789012:role/S3Access`
- Service-linked role: `arn:aws:iam::123456789012:role/aws-service-role/access-analyzer.amazonaws.com/AWSServiceRoleForAccessAnalyzer`
- A service role: `arn:aws:iam::123456789012:role/service-role/QuickSightAction`
- Managed policy: `arn:aws:iam::123456789012:policy/ManageCredentialsPermissions`
- Instance Profile: `arn:aws:sts::123456789012:federated-user/Paulo`
- Fedrated user: `arn:aws:iam::123456789012:server-certificate/ProdServerCert`
- Server certificate: `arn:aws:iam::123456789012:server-certificate/division_abc/subdivision_xyz/ProdServerCert`

### Unique Identifiers

When IAM creates a user, user group, role, policy, instance profile, or server certificate, it assigns a unique ID to each resource.

- The IAM unique ID looks like this:
  - `AIDAJQABLZS4A3QDU576Q`

## Endpoints

### General endpoints

Default is North Virginia us-east-1

- Amazon EC2 - ec2.amazonaws.com
- Amazon EC2 Auto Scaling - autoscaling.amazonaws.com
- Amazon EMR - elasticmapreduce.amazonaws.com

### Global endpoints

- Amazon CloudFront
- AWS Global Accelerator
- IAM
- AWS Network Manager
- AWS Organizations
- Amazon Route 53
- AWS Shield Advanced
- AWS WAF Classic

## Policy Practice
