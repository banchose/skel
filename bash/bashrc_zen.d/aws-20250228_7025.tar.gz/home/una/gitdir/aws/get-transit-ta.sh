#!/usr/bin/env bash

set -euo pipefail

AwsProfile="net"
AwsRegion="us-east-1"

# Fetch all Transit Gateway IDs
transit_gateways=$(aws ec2 describe-transit-gateways --query 'TransitGateways[].TransitGatewayId' --output text --region "${AwsRegion}" --profile "${AwsProfile}")

if [ -z "$transit_gateways" ]; then
  echo "No Transit Gateways found in region ${AwsRegion} for profile ${AwsProfile}."
  exit 0
fi

# Loop through each Transit Gateway ID
for tgw_id in $transit_gateways; do
  echo "Transit Gateway: $tgw_id"

  # Fetch associated Route Tables for the Transit Gateway
  route_tables=$(aws ec2 describe-transit-gateway-route-tables --region "${AwsRegion}" --profile "${AwsProfile}" \
    --filters "Name=transit-gateway-id,Values=$tgw_id" \
    --query 'TransitGatewayRouteTables[].TransitGatewayRouteTableId' \
    --output text)

  if [ -n "$route_tables" ]; then
    echo "  Route Tables:"
    for rt_id in $route_tables; do
      echo "    - $rt_id"
    done
  else
    echo "  - No Route Tables found"
  fi

  # Fetch attachments for the Transit Gateway
  attachments=$(aws ec2 describe-transit-gateway-attachments --region "${AwsRegion}" --profile "${AwsProfile}" \
    --filters "Name=transit-gateway-id,Values=$tgw_id" \
    --query 'TransitGatewayAttachments[*].[TransitGatewayAttachmentId,ResourceType,ResourceId,State]' \
    --output json)

  if [ "$attachments" != "[]" ]; then
    echo "  Attachments:"
    echo "$attachments" | jq -r '.[] | "    - AttachmentId: \(.0)\n      ResourceType: \(.1)\n      ResourceId: \(.2)\n      State: \(.3)"'

    # Fetch detailed network information for each attachment
    echo "  Associated Networks:"
    for attachment in $(echo "$attachments" | jq -r '.[][0]'); do
      network_info=$(aws ec2 describe-transit-gateway-attachments --region "${AwsRegion}" --profile "${AwsProfile}" \
        --transit-gateway-attachment-ids "$attachment" \
        --query 'TransitGatewayAttachments[0].Association.SubnetIds' \
        --output json)

      if [ "$network_info" != "null" ]; then
        echo "    - Attachment: $attachment"
        echo "      Subnets: $network_info"
      else
        echo "    - Attachment: $attachment has no associated subnets"
      fi
    done
  else
    echo "  - No Attachments found"
  fi

  echo "-------------------------------------"
done
