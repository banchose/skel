#!/usr/bin/env bash
set -euo pipefail

# model="llama-3.1-sonar-small-128k-online"
model="llama-3.1-sonar-large-128k-online"
# model="llama-3.1-sonar-huge-128k-online"

curl -s --location 'https://api.perplexity.ai/chat/completions' \
  --header 'accept: application/json' \
  --header 'content-type: application/json' \
  --header "Authorization: Bearer ${PERPLEXITY_API_KEY}" \
  --data '{
  "model": "'"${model}"'",
  "messages": [
    {
      "role": "system",
      "content": "Be precise and concise."
    },
    {
      "role": "user",
      "content": "How many stars are there in our galaxy?"
    }
  ]
}' | tee --append ~/temp/answers.json | jq '.'
