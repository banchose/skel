# pptxmodel="llama-3.1-sonar-small-128k-online"     # 8B
# pptxmodel="llama-3.1-sonar-large-128k-online"     # 70B
pptxmodel="llama-3.1-sonar-huge-128k-online" # 405B

maxinput=300

sanitize_input() {
  local input="$1"
  # Remove non-printable characters except for newline, and truncate to 300 characters
  sanitized_input=$(echo "$input" | tr -cd '[:print:]\n' | cut -c 1-${maxinput})
  echo "$sanitized_input"
}

query_perplexity() {
  # Check if API key is set
  if [[ -z "$PERPLEXITY_API_KEY" ]]; then
    echo "Error: PERPLEXITY_API_KEY is not defined. Please set it and try again." >&2
    exit 1
  fi

  # Check if input is provided either as a parameter or from stdin
  local content
  if [[ -n "$1" ]]; then
    content="$1"
  elif ! tty -s && read -r content; then
    : # Input from stdin
  else
    echo "Error: No input provided. Please provide input as a parameter or via stdin." >&2
    exit 1
  fi

  # Sanitize the input
  local sanitized_input
  sanitized_input=$(sanitize_input "$content")

  # API call with sanitized content
  curl -s --location 'https://api.perplexity.ai/chat/completions' \
    --header 'accept: application/json' \
    --header 'content-type: application/json' \
    --header "Authorization: Bearer ${PERPLEXITY_API_KEY}" \
    --data '{
      "model": "'"${pptxmodel}"'",
      "stream": false,
      "return_related_questions": false,
      "return_images": false,
      "search_recency_filter": "month",
      "max_tokens": 150,
      "messages": [
        {
          "role": "system",
          "content": "Be precise and concise."
        },
        {
          "role": "user",
          "content": "'"${sanitized_input}"'"
        }
      ]
    }' | tee --append ~/temp/answers.json | jq '.'
}

# Example usage:
# Passing input as a parameter:
# query_perplexity "Your input content here..."

# Passing input via stdin:
# echo "Your input content here..." | query_perplexity
