#!/usr/bin/env bash

#!/usr/bin/env bash

set -euo pipefail

AwsProfile="net"
AwsRegion="us-east-1"

# Fetch all Transit Gateway IDs
transit_gateways=$(aws ec2 describe-transit-gateways --query 'TransitGateways[].TransitGatewayId' --output text --region "${AwsRegion}" --profile "${AwsProfile}")

if [ -z "$transit_gateways" ]; then
  echo "No Transit Gateways found in region ${AwsRegion} for profile ${AwsProfile}."
  exit 0
fi

# Loop through each Transit Gateway ID
for tgw_id in $transit_gateways; do
  echo "Transit Gateway: $tgw_id"

  # Fetch associated Route Tables for the Transit Gateway
  route_tables=$(aws ec2 describe-transit-gateway-route-tables --region "${AwsRegion}" --profile "${AwsProfile}" \
    --filters "Name=transit-gateway-id,Values=$tgw_id" \
    --query 'TransitGatewayRouteTables[].TransitGatewayRouteTableId' \
    --output text)

  if [ -n "$route_tables" ]; then
    echo "  Route Tables:"
    for rt_id in $route_tables; do
      echo "    - $rt_id"
    done
  else
    echo "  - No Route Tables found"
  fi

  # Fetch attachments for the Transit Gateway
  attachments=$(aws ec2 describe-transit-gateway-attachments --region "${AwsRegion}" --profile "${AwsProfile}" \
    --filters "Name=transit-gateway-id,Values=$tgw_id" \
    --query 'TransitGatewayAttachments[*].[TransitGatewayAttachmentId,ResourceType,ResourceId,State]' \
    --output table)

  if [ -n "$attachments" ]; then
    echo "  Attachments:"
    echo "$attachments"
  else
    echo "  - No Attachments found"
  fi

  echo "-------------------------------------"
done
