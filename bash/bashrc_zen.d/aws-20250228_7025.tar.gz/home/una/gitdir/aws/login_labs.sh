#!/usr/bin/env bash

get_input() {
  local prompt="$1"
  local regex="$2"
  local input

  while true; do
    read -r -p "$prompt" input
    # Check against the regex if provided
    if [[ -n "$regex" && ! "$input" =~ $regex ]]; then
      echo "Invalid input. Please try again."
    else
      # Escape special characters to prevent injection
      input=$(printf '%q' "$input")
      echo "$input"
      return
    fi
  done
}

echo "#############################################"
echo "Login to LAB"
echo "#############################################"
aws configure sso --profile lab
echo "#############################################"
echo "Login to lab3"
echo "#############################################"
aws configure sso --profile lab3
echo "#############################################"

echo "LAB VPCs"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile lab
echo "LAB3 VPCs"
aws ec2 describe-vpcs --query 'Vpcs[*].[VpcId, CidrBlock, IsDefault, State, Tags[?Key==`Name`].Value | [0]]' --output table --region us-east-1 --profile lab3
