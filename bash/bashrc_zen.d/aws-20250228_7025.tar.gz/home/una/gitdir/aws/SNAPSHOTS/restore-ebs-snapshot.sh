#!/usr/bin/bash

set -euo pipefail

# SNAPSHOT_ID=snap-058f931fb05601161 # JUSTSTARTED
SNAPSHOT_ID=snap-03549f2a3118b8653 # WHOWHO?
INSTANCE_ID=i-0dc447e7fca5a8377
# SNAPSHOT_ID=snap-04c599d12b58bd16f # NEWVPC
AVAILABILITY_ZONE=

REGION=us-east-1
PROFILE=lab
DATE=$(date +%Y-%m-%d)
WAS_RUNNING=0
VOLUME_TYPE=gp3
DEVICE_NAME=/dev/xvda

check_command() {
  if [ $? -ne 0 ]; then
    echo "Error: ${1} failed. Exiting."
    exit 1
  fi
}

#
# Get the AZ of the instance
#

AVAILABILITY_ZONE="$(aws ec2 describe-instances \
  --instance-id "${INSTANCE_ID}" \
  --query "Reservations[].Instances[].Placement.AvailabilityZone" \
  --output text --region us-east-1)"
echo "AZ: $AVAILABILITY_ZONE"
#
# Get the volume id to be replaced
#

OLD_VOLUME_ID="$(aws ec2 describe-instances \
  --instance-id "${INSTANCE_ID}" \
  --query "Reservations[].Instances[].BlockDeviceMappings[?DeviceName=='/dev/xvda'].Ebs.VolumeId" \
  --output text --region us-east-1)"
check_command "Get OLD volume id that will be REPLACED at /dev/xvda"
echo "Old volume: $OLD_VOLUME_ID"

#
# Create new volume from the snapshot
#

NEW_VOLUME_ID=$(aws ec2 create-volume \
  --snapshot-id "${SNAPSHOT_ID}" \
  --availability-zone "${AVAILABILITY_ZONE}" \
  --volume-type "${VOLUME_TYPE}" \
  --query "VolumeId" \
  --output text \
  --region "${REGION}" \
  --profile "${PROFILE}")
echo "New volume ${NEW_VOLUME_ID} created from snapshot: ${SNAPSHOT_ID}"
echo "REPLACING ${OLD_VOLUME_ID}"

aws ec2 wait volume-available --volume-ids "${NEW_VOLUME_ID}" --region "${REGION}" --profile "${PROFILE}"
echo "Volume ${NEW_VOLUME_ID} is now available."

#
# Get instance running state
#

INSTANCE_STATE=$(aws ec2 describe-instances \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --query "Reservations[*].Instances[*].State.Name" \
  --output text --profile "${PROFILE}")
check_command "Getting instance state"
echo "Aquired instance state for ${INSTANCE_ID}"

#
# Stop instance
#

if [[ ${INSTANCE_STATE} == "running" ]]; then
  aws ec2 stop-instances \
    --instance-ids "${INSTANCE_ID}" \
    --region "${REGION}" \
    --profile "${PROFILE}"
  check_command "Stop instance ${INSTANCE_ID}"
  WAS_RUNNING=1
fi
echo "Issued command to stop ${INSTANCE_ID}"

#
# Wait for the ec2 to stop
#
aws ec2 wait instance-stopped --instance-ids "${INSTANCE_ID}" --region "${REGION}"
check_command "Wait for ec2 to stop"
echo "Instance ${INSTANCE_ID} stopped"

aws ec2 describe-instances \
  --instance-id "${INSTANCE_ID}" \
  --query "Reservations[].Instances[].BlockDeviceMappings[?DeviceName=='${DEVICE_NAME}'].Ebs.VolumeId" \
  --output text \
  --region us-east-1 \
  --profile "${PROFILE}"

echo "${OLD_VOLUME_ID}"

#
# Detach old volume from ec2 instance
#

aws ec2 detach-volume \
  --volume-id "${OLD_VOLUME_ID}" \
  --region us-east-1 \
  --profile "${PROFILE}"

#
# Wait for the old volume to detach
#
echo "Wait for volume after detach"
aws ec2 wait volume-available \
  --volume-ids "${OLD_VOLUME_ID}" \
  --region us-east-1 \
  --profile "${PROFILE}"

<<<<<<< HEAD
echo "sleep 3"
sleep 3

aws ec2 attach-volume --device "${DEVICE_NAME}" \
  --volume-id "${NEW_VOLUME_ID}" \
  --instance-id "${INSTANCE_ID}"
=======
#
# Attach the new volume to the instance as the root device (/dev/xvda) ch
#

aws ec2 attach-volume \
  --volume-id "${NEW_VOLUME_ID}" \
  --instance-id "${INSTANCE_ID}" \
  --device "${DEVICE_NAME}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Attach new volume ${NEW_VOLUME_ID} to ${INSTANCE_ID} as ${DEVICE_NAME}"
echo "New volume ${NEW_VOLUME_ID} attached to ${INSTANCE_ID} as ${DEVICE_NAME}"

#
# Wait for the new volume to attach
#

aws ec2 wait volume-in-use \
  --volume-ids "${NEW_VOLUME_ID}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Wait for volume ${NEW_VOLUME_ID} to be attached to ${INSTANCE_ID}"
echo "Volume ${NEW_VOLUME_ID} is now attached to ${INSTANCE_ID}"

#
# Start the instance if it was running before
#

if [[ ${WAS_RUNNING} -eq 1 ]]; then
  aws ec2 start-instances \
    --instance-ids "${INSTANCE_ID}" \
    --region "${REGION}" \
    --profile "${PROFILE}"
  check_command "Start instance ${INSTANCE_ID}"
  echo "Instance ${INSTANCE_ID} has been started"
fi

#
# Wait for the instance to reach the 'running' state
#

aws ec2 wait instance-running \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Wait for instance ${INSTANCE_ID} to reach 'running' state"
echo "Instance ${INSTANCE_ID} is now running"
>>>>>>> d79ec8c17aabf8daff25a63110fbaf6d92c544c4
