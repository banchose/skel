#!/bin/bash

# Set AWS Profile and Region
AWS_PROFILE="lab"
AWS_REGION="us-east-1"

# Get list of snapshots and let user select one
SNAPSHOT_ID=$(
  aws ec2 describe-snapshots \
    --profile "$AWS_PROFILE" \
    --region "$AWS_REGION" \
    --owner-ids self \
    --query "Snapshots[*].SnapshotId" \
    --output text | tr '\t' '\n' | fzf --prompt="Select a Snapshot ID: "
)

# Exit if no snapshot is selected
if [[ -z "$SNAPSHOT_ID" ]]; then
  echo "No snapshot selected. Exiting..."
  exit 1
fi

# Get list of availability zones and let user select one
AVAILABILITY_ZONE=$(aws ec2 describe-availability-zones \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --query "AvailabilityZones[*].ZoneName" \
  --output text | tr '\t' '\n' | fzf --prompt="Select an Availability Zone: ")

# Exit if no AZ is selected
if [[ -z "$AVAILABILITY_ZONE" ]]; then
  echo "No Availability Zone selected. Exiting..."
  exit 1
fi

# Get list of volume types and let user select one
VOLUME_TYPE=$(echo -e "gp3\ngp2\nio1\nio2\nsc1\nst1" | fzf --prompt="Select a Volume Type: ")

# Exit if no volume type is selected
if [[ -z "$VOLUME_TYPE" ]]; then
  echo "No volume type selected. Exiting..."
  exit 1
fi

# Create the volume with the selected options
echo "Creating volume with Snapshot ID: $SNAPSHOT_ID, AZ: $AVAILABILITY_ZONE, Volume Type: $VOLUME_TYPE"

aws ec2 create-volume \
  --snapshot-id "$SNAPSHOT_ID" \
  --volume-type "$VOLUME_TYPE" \
  --availability-zone "$AVAILABILITY_ZONE" \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
