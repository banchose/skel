#!/usr/bin/bash

set -euo pipefail

aws ec2 describe-instances --query "Reservations[*].Instances[*].PublicIpAddress" --output text --profile lab
