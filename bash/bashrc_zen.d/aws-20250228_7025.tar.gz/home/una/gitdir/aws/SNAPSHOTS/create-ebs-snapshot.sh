#!/usr/bin/bash

set -euo pipefail

INSTANCE_ID=i-0dc447e7fca5a8377

REGION=us-east-1
PROFILE=lab
DATE=$(date +%Y-%m-%d)
WAS_RUNNING=0

check_command() {
  if [ $? -ne 0 ]; then
    echo "Error: ${1} failed. Exiting."
    exit 1
  fi
}

#
# Function: Validate EC2 instance ID format
#

validate_instance_id() {
  local instance_id="${1}"
  if [[ "$instance_id" =~ ^i-[0-9a-f]{17}$ ]]; then
    return 0 # Valid
  else
    echo "Error: Invalid instance ID '${instance_id}'."
    echo "An instance ID must follow the format 'i-xxxxxxxxxxxxxxxxx'."
    exit 1
  fi
}

#
# Validate first parameter ec2 instance id
#

validate_instance_id "${1}"
INSTANCE_ID="${1}"

#
# Get instance state
#

INSTANCE_STATE=$(aws ec2 describe-instances \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --query "Reservations[*].Instances[*].State.Name" \
  --output text --profile "${PROFILE}")
check_command "Getting instance state"
echo "Aquired instance state for ${INSTANCE_ID}"

#
# Stop instance
#

if [[ ${INSTANCE_STATE} == "running" ]]; then
  aws ec2 stop-instances \
    --instance-ids "${INSTANCE_ID}" \
    --region "${REGION}" \
    --profile "${PROFILE}"
  check_command "Stop instance ${INSTANCE_ID}"
  WAS_RUNNING=1
fi
echo "Issued command to stop ${INSTANCE_ID}"

#
# Wait for the ec2 to stop
#

aws ec2 wait instance-stopped --instance-ids "${INSTANCE_ID}" --region "${REGION}"
check_command "Wait for ec2 to stop"
echo "Instance ${INSTANCE_ID} stopped"

#
# Get Volume IDs
#

VOLUME_IDS=$(aws ec2 describe-instances \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --query "Reservations[*].Instances[*].BlockDeviceMappings[*].Ebs.VolumeId" \
  --output text --profile "${PROFILE}")
check_command "Get volume ids form found ec2 instances"
[[ -z ${VOLUME_IDS} ]] && {
  echo "No volume ids found for ${INSTANCE_ID}"
  exit 1
}
echo "Gathered volumes from ${INSTANCE_ID}"
echo "VOLUME_IDS: ${VOLUME_IDS}"

#
# Loop through found volumes and snapshot each
#

echo "Starting snapshots for ${INSTANCE_ID}"
echo "For volumes: ${VOLUME_IDS}"

for VOLUME_ID in ${VOLUME_IDS}; do
  echo "Creating snapshot for volume ${VOLUME_ID}..."
  SNAPSHOT_ID=$(aws ec2 create-snapshot \
    --volume-id "${VOLUME_ID}" \
    --description "Snapshot of ${VOLUME_ID} on ${DATE}" \
    --region "${REGION}" \
    --profile "${PROFILE}")
  check_command "Creating snapshot for volume ${VOLUME_ID}"
  echo "Snapshot ${SNAPSHOT_ID} for volume ${VOLUME_ID} created successfully."
done

if [[ -n $WAS_RUNNING ]]; then
  echo "Initially running instance is being restarted from a stopped state"
  aws ec2 start-instances --instance-ids "${INSTANCE_ID}"
  echo "Waiting on a friend: ${INSTANCE_ID}"
  aws ec2 wait instance-running --instance-ids "${INSTANCE_ID}"
  check_command "Wating on a friend: ${INSTANCE_ID}"
fi
