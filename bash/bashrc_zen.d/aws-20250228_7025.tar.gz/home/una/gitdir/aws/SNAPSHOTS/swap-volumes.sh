#!/usr/bin/bash

set -euo pipefail

INSTANCE_ID=i-0dc447e7fca5a8377
NEW_VOLUME_ID=vol-036c75c561e5d0133
#
# NEW_VOLUME_ID=vol-02bae8073e6eadd9f

REGION=us-east-1
PROFILE=lab
DATE=$(date +%Y-%m-%d)
WAS_RUNNING=0
VOLUME_TYPE=gp3
DEVICE_NAME=/dev/xvda

check_command() {
  if [ $? -ne 0 ]; then
    echo "Error: ${1} failed. Exiting."
    exit 1
  fi
}

#
# Get instance state
#

INSTANCE_STATE=$(aws ec2 describe-instances \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --query "Reservations[*].Instances[*].State.Name" \
  --output text --profile "${PROFILE}")
check_command "Getting instance state"
echo "Aquired instance state for ${INSTANCE_ID}"

#
# Get original root volume id
#

OLD_VOLUME_ID="$(aws ec2 describe-instances \
  --instance-id "${INSTANCE_ID}" \
  --query "Reservations[].Instances[].BlockDeviceMappings[?DeviceName=='/dev/xvda'].Ebs.VolumeId" \
  --output text --region us-east-1)"
check_command "Get OLD volume id that will be REPLACED at /dev/xvda"
echo "${OLD_VOLUME_ID}"

#
# Stop instance if running
#

if [[ ${INSTANCE_STATE} == "running" ]]; then
  aws ec2 stop-instances \
    --instance-ids "${INSTANCE_ID}" \
    --region "${REGION}" \
    --profile "${PROFILE}"
  check_command "Stop instance ${INSTANCE_ID}"
  WAS_RUNNING=1
fi

echo "Issued command to stop ${INSTANCE_ID}"

#
# Wait for the ec2 to stop
#

aws ec2 wait instance-stopped --instance-ids "${INSTANCE_ID}" --region "${REGION}"
check_command "Wait for ec2 to stop"
echo "Instance ${INSTANCE_ID} stopped"

#
# Detach old volume from ec2 instance
#

aws ec2 detach-volume \
  --volume-id "${OLD_VOLUME_ID}" \
  --region us-east-1 \
  --profile "${PROFILE}"

#
# Wait for the old volume to detach
#

aws ec2 wait volume-available \
  --volume-ids "${OLD_VOLUME_ID}" \
  --region us-east-1 \
  --profile "${PROFILE}"

#
# Attach the new volume to the instance as the root device (/dev/xvda) ch
#

aws ec2 attach-volume \
  --volume-id "${NEW_VOLUME_ID}" \
  --instance-id "${INSTANCE_ID}" \
  --device "${DEVICE_NAME}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Attach new volume ${NEW_VOLUME_ID} to ${INSTANCE_ID} as ${DEVICE_NAME}"
echo "New volume ${NEW_VOLUME_ID} attached to ${INSTANCE_ID} as ${DEVICE_NAME}"

#
# Wait for the new volume to attach
#

aws ec2 wait volume-in-use \
  --volume-ids "${NEW_VOLUME_ID}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Wait for volume ${NEW_VOLUME_ID} to be attached to ${INSTANCE_ID}"
echo "Volume ${NEW_VOLUME_ID} is now attached to ${INSTANCE_ID}"

#
# Start the instance if it was running before
#

if [[ ${WAS_RUNNING} -eq 1 ]]; then
  aws ec2 start-instances \
    --instance-ids "${INSTANCE_ID}" \
    --region "${REGION}" \
    --profile "${PROFILE}"
  check_command "Start instance ${INSTANCE_ID}"
  echo "Instance ${INSTANCE_ID} has been started"
fi

#
# Wait for the instance to reach the 'running' state
#

aws ec2 wait instance-running \
  --instance-ids "${INSTANCE_ID}" \
  --region "${REGION}" \
  --profile "${PROFILE}"
check_command "Wait for instance ${INSTANCE_ID} to reach 'running' state"
echo "Instance ${INSTANCE_ID} is now running"
