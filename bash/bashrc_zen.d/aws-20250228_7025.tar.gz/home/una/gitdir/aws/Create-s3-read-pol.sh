aws iam put-role-policy --role-name RDS-S3-Restore-Role \
  --profile production \
  --region us-east-1 \
  --policy-name S3BackupRestorePolicy \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Action": [
          "s3:GetObject",
          "s3:ListBucket"
        ],
        "Resource": [
          "arn:aws:s3:::hri-my-access-gateway-bucket",
          "arn:aws:s3:::hri-my-access-gateway-bucket/*"
        ]
      }
    ]
  }'
