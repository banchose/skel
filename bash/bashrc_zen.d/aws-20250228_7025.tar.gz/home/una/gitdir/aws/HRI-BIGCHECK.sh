command -v cowsay &>/dev/null && cowsay "Herrrrrrre goes..."
echo "########################"
echo "Checking corp.healthresearch.org FORWARD DNS"
echo "########################"
nslookup alb-prd-dc-3.corp.healthresearch.org
echo "########################"
echo "Checking corp.healthresearch.org REVERSE DNS"
echo "########################"
nslookup 10.1.100.100
nslookup 10.1.100.101
echo "########################"
echo "Checking PING DNS name prem HRI alb-prd-dc-3"
echo "########################"
ping -l 1 -c 3 alb-prd-dc-3
echo "########################"
echo "Checking PING to on prem HRI DMZ alb-prd-dc-3"
echo "########################"
ping -l 1 -c 3 alb-prd-zdns-1
echo "########################"
echo "Checking PING to on prem HRI IP"
echo "########################"
ping -l 1 -c 2 10.1.100.100
ping -l 1 -c 2 10.1.100.101
echo "########################"
echo "Checking PING to Internet IP"
echo "########################"
ping -l 1 -c 3 1.1.1.1
echo "########################"
echo "Checking PING to Internet DNS"
echo "########################"
ping -l 1 -c 3 www.cnn.com
echo "########################"
echo "Checking ssh"
echo "########################"
curl -s --connect-timeout 2 www.cnn.com:80 >/dev/null 2>&1 && echo "Connected to cnn 80"

# echo "DID YOU PUT A CURRENT vMX KEY IN"
# echo ""
# echo "CHECK /etc/resolv.conf"
# echo ""
# echo "CHECK TGW Associations"
# echo ""
# echo "Done in the network account once attachment is created in other account"
# echo "Needs: AWS::EC2::TransitGatewayRouteTableAssociation"
# echo "Needs: AWS::EC2::TransitGatewayRouteTableAssociation"
# echo "****************************************"
# echo " DNS forwarding rules - No hosted zone needed"
# echo "****************************************"
# echo "Are the resolver endpoints created"
# echo "Have the resolver (dns forwareding rule to corp.healthresearch.org) rules been associated with a vpc"
# echo "AWS::Route53Resolver::ResolverRuleAssociation"
# echo "AWS::Route53Resolver::ResolverEndpoint"
# echo "Has the forwarding rule been created"
# echo "In NETWORK BIGAWSDNS acct has dns servers: AWS::Route53Resolver::ResolverRule"
# echo "The DNS endpoint security group allows 53 UDP TCP"
# echo "****************************************"
# echo " DNS Private Hosted Zone - vpc dns '.2' will use it when associated with vpc"
# echo "****************************************"
# echo "Did you create echo AWS::Route53::HostedZone"
# echo "Did you associate within AWS::Route53::HostedZone all the vpcs that will use it"

# BIGNETWORK Resources
# AWS::RAM::ResourceShare
# AWS::NetworkFirewall::RuleGroup
# AWS::NetworkFirewall::RuleGroup
# AWS::NetworkFirewall::LoggingConfiguration
# AWS::NetworkFirewall::FirewallPolicy
# AWS::NetworkFirewall::Firewall
# AWS::Logs::LogGroup
# AWS::Logs::LogGroup
# AWS::IAM::Role
# AWS::IAM::InstanceProfile
# AWS::EC2::VPCGatewayAttachment
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCEndpoint
# AWS::EC2::VPCDHCPOptionsAssociation
# AWS::EC2::VPCDHCPOptionsAssociation
# AWS::EC2::VPCDHCPOptionsAssociation
# AWS::EC2::VPC
# AWS::EC2::VPC
# AWS::EC2::VPC
# AWS::EC2::TransitGatewayRouteTablePropagation
# AWS::EC2::TransitGatewayRouteTablePropagation
# AWS::EC2::TransitGatewayRouteTableAssociation
# AWS::EC2::TransitGatewayRouteTableAssociation
# AWS::EC2::TransitGatewayRouteTableAssociation
# AWS::EC2::TransitGatewayRouteTable
# AWS::EC2::TransitGatewayRoute
# AWS::EC2::TransitGatewayAttachment
# AWS::EC2::TransitGatewayAttachment
# AWS::EC2::TransitGatewayAttachment
# AWS::EC2::TransitGateway
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::SubnetRouteTableAssociation
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::Subnet
# AWS::EC2::SecurityGroup
# AWS::EC2::SecurityGroup
# AWS::EC2::SecurityGroup
# AWS::EC2::SecurityGroup
# AWS::EC2::SecurityGroup
# AWS::EC2::RouteTable
# AWS::EC2::RouteTable
# AWS::EC2::RouteTable
# AWS::EC2::RouteTable
# AWS::EC2::RouteTable
# AWS::EC2::RouteTable
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::Route
# AWS::EC2::NatGateway
# AWS::EC2::LaunchTemplate
# AWS::EC2::InternetGateway
# AWS::EC2::Instance
# AWS::EC2::Instance
# AWS::EC2::Instance
# AWS::EC2::EIP
# AWS::EC2::DHCPOptions
# AWS::EC2::TransitGatewayRouteTablePropagation
# AWS::EC2::TransitGatewayRouteTableAssociation
# AWS::EC2::TransitGatewayRouteTableAssociation
# AWS::EC2::TransitGatewayRouteTablePropagation
#
### BIGDEV RESOURCES
#   AWS::IAM::Role
#   AWS::IAM::InstanceProfile
#   AWS::EC2::VPCEndpoint
#   AWS::EC2::VPCEndpoint
#   AWS::EC2::VPCEndpoint
#   AWS::EC2::VPCEndpoint
#   AWS::EC2::VPCEndpoint
#   AWS::EC2::VPCDHCPOptionsAssociation
#   AWS::EC2::VPC
#   AWS::EC2::TransitGatewayAttachment
#   AWS::EC2::SubnetRouteTableAssociation
#   AWS::EC2::SubnetRouteTableAssociation
#   AWS::EC2::Subnet
#   AWS::EC2::Subnet
#   AWS::EC2::SecurityGroup
#   AWS::EC2::SecurityGroup
#   AWS::EC2::RouteTable
#   AWS::EC2::Route
#   AWS::EC2::LaunchTemplate
#   AWS::EC2::Instance
#   AWS::EC2::DHCPOptions
#   AWS::Route53Resolver::ResolverRuleAssociation
#   AWS::Route53Resolver::ResolverRuleAssociation
#   AWS::Route53Resolver::ResolverEndpoint
#   AWS::EC2::SecurityGroup
