#!/usr/bin/env bash

set -euo pipefail

AwsProfile="net"
AwsRegion="us-east-1"

# Fetch all security groups in the region
security_groups=$(aws ec2 describe-security-groups --region "${AwsRegion}" --profile "${AwsProfile}" \
  --query 'SecurityGroups[*]' --output json)

if [ "$security_groups" == "[]" ]; then
  echo "No security groups found in region ${AwsRegion} for profile ${AwsProfile}."
  exit 0
fi

# Display security groups and rules
echo "Listing all security groups and their rules in region ${AwsRegion} for profile ${AwsProfile}:"
echo "$security_groups" | jq -r '
  .[] | 
  "Security Group:\n  GroupId: \(.GroupId)\n  GroupName: \(.GroupName // "No Name")\n  Inbound Rules:" +
  (if (.IpPermissions | length) > 0 then
    (.IpPermissions | map(
      "    - Protocol: \(.IpProtocol)\n      Ports: \((.FromPort // "All") | tostring)-\((.ToPort // "All") | tostring)\n      Sources: \((.IpRanges | map(.CidrIp) | join(", ")) // "None")"
    ) | join("\n"))
  else
    "\n    None"
  end) +
  "\n  Outbound Rules:" +
  (if (.IpPermissionsEgress | length) > 0 then
    (.IpPermissionsEgress | map(
      "    - Protocol: \(.IpProtocol)\n      Ports: \((.FromPort // "All") | tostring)-\((.ToPort // "All") | tostring)\n      Destinations: \((.IpRanges | map(.CidrIp) | join(", ")) // "None")"
    ) | join("\n"))
  else
    "\n    None"
  end)
'
