#!/bin/bash

set -euo pipefail

# Fetch all VPC IDs in the account and region
vpcs=$(aws ec2 describe-vpcs --query 'Vpcs[].VpcId' --output text)

echo "Listing EC2 instances for each VPC in the region..."

# Loop through each VPC ID
for vpc_id in $vpcs; do
  echo "VPC: $vpc_id"

  # Fetch EC2 instances in the VPC
  instances=$(aws ec2 describe-instances \
    --filters "Name=vpc-id,Values=$vpc_id" \
    --query 'Reservations[*].Instances[*].[InstanceId,State.Name,InstanceType,PrivateIpAddress]' \
    --output table)

  if [ -z "$instances" ]; then
    echo "  No EC2 instances found in this VPC."
  else
    echo "$instances"
  fi

  echo "-------------------------------------"
done
