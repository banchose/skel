check_stack_status() {
  # Parameters
  local stack_name="$1"

  if [[ -z "$stack_name" ]]; then
    echo "Usage: check_stack_status <stack-name>"
    return 1
  fi

  echo "Checking status of stack: $stack_name"

  while true; do
    # Get the current stack status
    stack_status=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].StackStatus" --output text 2>/dev/null)

    if [[ $? -ne 0 ]]; then
      echo "Error: Unable to retrieve stack status. Ensure the stack name is correct."
      return 1
    fi

    echo "Current stack status: $stack_status"

    case "$stack_status" in
    CREATE_COMPLETE | UPDATE_COMPLETE)
      echo "Stack operation successful. Exiting."
      return 0
      ;;
    CREATE_FAILED | ROLLBACK_COMPLETE | ROLLBACK_FAILED | DELETE_FAILED | UPDATE_ROLLBACK_FAILED)
      echo "Error: Stack operation failed with status: $stack_status"
      return 1
      ;;
    *)
      echo "Stack operation in progress... Checking again in 5 seconds."
      sleep 5
      ;;
    esac
  done
}
