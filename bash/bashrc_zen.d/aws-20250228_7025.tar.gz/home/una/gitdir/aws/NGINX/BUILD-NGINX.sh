#!/usr/bin/env bash

set -euo pipefail

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

reverse_ip() {
  local ip="$1"

  # Validate the input IP address
  if [[ ! "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
    echo "Error: Invalid IP address format" >&2
    return 1
  fi

  # Split the IP into an array and reverse the octets
  IFS='.' read -r -a octets <<<"$ip"
  echo "${octets[3]}.${octets[2]}.${octets[1]}.${octets[0]}.in-addr.arpa"
}

# Puts in dev
# Security Group is broad but local
#
set_stack_outputs HRI-BIGNETWORK us-east-1 net
set_stack_outputs HRI-BIGAWSDNS us-east-1 net
set_stack_outputs HRI-BIGDEV us-east-1 dev

# aws cloudformation create-stack \
#   --stack-name HRI-NGINX \
#   --template-body file://./HRI-NGINX.yaml \
#   --parameters ParameterKey="pTargetSubnetId",ParameterValue="${rDevWorkloadPrivateSubnet}" \
#   ParameterKey="pSshKeyPair",ParameterValue="HRI-BIGDEV" \
#   ParameterKey="pTargetVpcId",ParameterValue="${rDevVpcId}" \
#   --region us-east-1 \
#   --profile dev

hang_fire HRI-NGINX dev

revipdnsaddr="$(reverse_ip "${AcmeEc2InstancePrivateIp}")"
echo "Reverse DNS: ${revipdnsaddr}"
echo "Ec2 Instance Ip: ${AcmeEc2InstancePrivateIp}"

aws cloudformation create-stack \
  --stack-name AddNginxDnsARecord \
  --template-body file://./AddNginxDnsARecord.yaml \
  --parameters ParameterKey="pForwardHostedZoneId",ParameterValue="${rHriAwsPrivateHostedZone}" \
  ParameterKey="pForwardHostedZoneRevId",ParameterValue="${rHriAwsPrivateHostedZoneRev}" \
  ParameterKey="pHostName",ParameterValue="${pHostName}.aws.healthresearch.org" \
  ParameterKey="pHostIpAddress",ParameterValue="${AcmeEc2InstancePrivateIp}" \
  ParameterKey="pRevHostName",ParameterValue="${revipdnsaddr}" \
  --region us-east-1 \
  --profile net

hang_fire AddNginxDnsARecord net
