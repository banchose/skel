#!/usr/bin/env bash

set -euo pipefail

aws cloudformation create-stack \
  --stack-name SingleIpVpcEc2-small-nv \
  --template-body file://./SingleIpVpcEc2-small-nv.yaml \
  --region us-east-1 \
  --profile lab
