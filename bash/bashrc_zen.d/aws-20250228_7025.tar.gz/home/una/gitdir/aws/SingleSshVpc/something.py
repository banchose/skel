import boto3
import cfnresponse
import logging

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    logger.info("Received event: %s", event)
    ec2 = boto3.client('ec2')

    try:
        # Validate the event structure
        if 'ResourceProperties' not in event or 'VpcId' not in event['ResourceProperties']:
            raise ValueError("Missing 'VpcId' in ResourceProperties")

        vpc_id = event['ResourceProperties']['VpcId']
        logger.info("Fetching CIDR block for VPC: %s", vpc_id)

        # Call describe_vpcs and check for errors
        response = ec2.describe_vpcs(VpcIds=[vpc_id])
        if not response['Vpcs']:
            raise ValueError(f"No VPC found with ID: {vpc_id}")

        cidr_block = response['Vpcs'][0]['CidrBlock']
        logger.info("CIDR block retrieved: %s", cidr_block)

        # Send SUCCESS response to CloudFormation
        response_data = {'CidrBlock': cidr_block}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)

    except Exception as e:
        logger.error("Error occurred: %s", str(e), exc_info=True)
        # Always send a FAILURE response to CloudFormation
        response_data = {'Message': str(e)}
        try:
            cfnresponse.send(event, context, cfnresponse.FAILED, response_data)
        except Exception as send_error:
            logger.critical("Failed to send response to CloudFormation: %s", str(send_error))


