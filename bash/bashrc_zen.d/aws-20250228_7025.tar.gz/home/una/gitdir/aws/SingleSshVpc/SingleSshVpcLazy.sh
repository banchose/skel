#!/usr/bin/env bash

set -euo pipefail

aws cloudformation create-stack \
  --stack-name SingleIpVpcEc2Lazy \
  --template-body file://./SingleIpVpcEc2-small-nvim-lazyvim-wjs04.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --profile lab
