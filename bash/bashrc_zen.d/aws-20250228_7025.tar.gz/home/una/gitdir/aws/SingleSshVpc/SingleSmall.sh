#!/usr/bin/env bash

set -euo pipefail

aws cloudformation create-stack \
  --stack-name SingleIpVpcEc2 \
  --template-body file://./SingleIpVpcEc2.yaml \
  --region us-east-1 \
  --profile lab3
