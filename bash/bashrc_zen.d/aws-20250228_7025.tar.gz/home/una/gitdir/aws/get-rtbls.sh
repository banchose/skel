#!/usr/bin/env bash

set -euo pipefail

AwsProfile="net"
AwsRegion="us-east-1"

# Fetch all route tables in the region
echo "Listing all route tables in region ${AwsRegion} for profile ${AwsProfile}:"
aws ec2 describe-route-tables --region "${AwsRegion}" --profile "${AwsProfile}" \
  --query 'RouteTables[*].{RouteTableId:RouteTableId, VpcId:VpcId, Name:Tags[?Key==`Name`].Value | [0]}' \
  --output table
