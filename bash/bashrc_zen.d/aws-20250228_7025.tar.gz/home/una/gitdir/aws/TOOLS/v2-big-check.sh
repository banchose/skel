#!/bin/bash

# Define color and symbols
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color
CHECK_MARK="${GREEN}✓${NC}"
CROSS_MARK="${RED}✗${NC}"

# Function to print status
print_status() {
  local test_name="$1"
  local success="$2"
  local details="$3"

  if [[ "$success" -eq 0 ]]; then
    printf "%-40s ${CHECK_MARK} ${GREEN}Success${NC}\n" "$test_name"
    [[ -n "$details" ]] && echo "  $details"
  else
    printf "%-40s ${CROSS_MARK} ${RED}Failed${NC}\n" "$test_name"
    [[ -n "$details" ]] && echo "  $details"
  fi
}

# Check for cowsay
if command -v cowsay &>/dev/null; then
  cowsay "Herrrrrrre goes..."
fi

echo "============== DNS and Network Connectivity Tests =============="

# Test Forward DNS (FQDN)
result=$(nslookup alb-prd-dc-3.corp.healthresearch.org 2>&1)
if echo "$result" | grep -q "Address:"; then
  ip=$(echo "$result" | grep "Address:" | tail -1 | awk '{print $2}')
  print_status "corp.healthresearch.org FORWARD DNS" 0 "Resolved to $ip"
else
  print_status "corp.healthresearch.org FORWARD DNS" 1 "Could not resolve"
fi

# Test Single Label DNS
result=$(nslookup alb-prd-dc-3 2>&1)
if echo "$result" | grep -q "Address:"; then
  ip=$(echo "$result" | grep "Address:" | tail -1 | awk '{print $2}')
  print_status "Single Label FORWARD DNS" 0 "Resolved to $ip"
else
  print_status "Single Label FORWARD DNS" 1 "Could not resolve"
fi

# Test Reverse DNS
result=$(nslookup 10.1.100.100 2>&1)
if echo "$result" | grep -q "name ="; then
  name=$(echo "$result" | grep "name = " | awk '{print $4}')
  print_status "REVERSE DNS for 10.1.100.100" 0 "Resolved to $name"
else
  print_status "REVERSE DNS for 10.1.100.100" 1 "No reverse record found"
fi

result=$(nslookup 10.1.100.101 2>&1)
if echo "$result" | grep -q "name ="; then
  name=$(echo "$result" | grep "name = " | awk '{print $4}')
  print_status "REVERSE DNS for 10.1.100.101" 0 "Resolved to $name"
else
  print_status "REVERSE DNS for 10.1.100.101" 1 "No reverse record found"
fi

# Test ping to on-prem DNS
result=$(ping -l 1 -c 3 alb-prd-dc-3 2>&1)
ping_status=$?
if [[ "$ping_status" -eq 0 ]]; then
  avg_time=$(echo "$result" | grep "avg" | awk -F'/' '{print $5}')
  print_status "PING alb-prd-dc-3" 0 "Average RTT: ${avg_time}ms"
else
  print_status "PING alb-prd-dc-3" 1
fi

# Test ping to DMZ
result=$(ping -l 1 -c 3 alb-prd-zdns-1 2>&1)
ping_status=$?
if [[ "$ping_status" -eq 0 ]]; then
  avg_time=$(echo "$result" | grep "avg" | awk -F'/' '{print $5}')
  print_status "PING alb-prd-zdns-1" 0 "Average RTT: ${avg_time}ms"
else
  print_status "PING alb-prd-zdns-1" 1
fi

# Test ping to on-prem IPs
for ip in 10.1.100.100 10.1.100.101; do
  result=$(ping -l 1 -c 2 "$ip" 2>&1)
  ping_status=$?
  if [[ "$ping_status" -eq 0 ]]; then
    avg_time=$(echo "$result" | grep "avg" | awk -F'/' '{print $5}')
    print_status "PING $ip" 0 "Average RTT: ${avg_time}ms"
  else
    print_status "PING $ip" 1
  fi
done

# Test internet connectivity via IP
result=$(ping -l 1 -c 3 1.1.1.1 2>&1)
ping_status=$?
if [[ "$ping_status" -eq 0 ]]; then
  avg_time=$(echo "$result" | grep "avg" | awk -F'/' '{print $5}')
  print_status "Internet connectivity (1.1.1.1)" 0 "Average RTT: ${avg_time}ms"
else
  print_status "Internet connectivity (1.1.1.1)" 1
fi

# Test internet DNS resolution
result=$(ping -l 1 -c 3 www.cnn.com 2>&1)
ping_status=$?
if [[ "$ping_status" -eq 0 ]]; then
  avg_time=$(echo "$result" | grep "avg" | awk -F'/' '{print $5}')
  print_status "Internet DNS (www.cnn.com)" 0 "Average RTT: ${avg_time}ms"
else
  print_status "Internet DNS (www.cnn.com)" 1
fi

# Test HTTP connectivity
if curl -s --connect-timeout 2 www.cnn.com:80 >/dev/null 2>&1; then
  print_status "HTTP connection to www.cnn.com:80" 0 "Connection successful"
else
  print_status "HTTP connection to www.cnn.com:80" 1
fi

echo "======================== Test Summary =========================="
