import boto3
import argparse
import sys
import logging
from botocore.exceptions import BotoCoreError, ClientError
from typing import Dict, Any
from colorama import Fore, Style, init

# Initialize colorama for cross-platform support
init(autoreset=True)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

def parse_arguments() -> argparse.Namespace:
    """
    Parse command-line arguments.
    Returns:
        argparse.Namespace: Parsed arguments.
    """
    parser = argparse.ArgumentParser(description="List Transit Gateway Attachments with VPC names.")
    parser.add_argument(
        "--profile", required=True, help="The AWS CLI profile to use for authentication."
    )
    return parser.parse_args()

def initialize_session(profile: str) -> boto3.Session:
    """
    Initialize a Boto3 session using the specified profile.
    Args:
        profile (str): The AWS CLI profile name.
    Returns:
        boto3.Session: The initialized session.
    """
    try:
        return boto3.Session(profile_name=profile)
    except (BotoCoreError, ClientError) as e:
        logger.error(f"Error initializing session: {e}")
        sys.exit(1)

def fetch_transit_gateway_attachments(ec2_client: Any) -> Dict[str, Any]:
    """
    Fetch Transit Gateway Attachments filtered by resource type 'vpc'.
    Args:
        ec2_client: The EC2 client object.
    Returns:
        Dict[str, Any]: The Transit Gateway Attachments.
    """
    try:
        return ec2_client.describe_transit_gateway_attachments(
            Filters=[{"Name": "resource-type", "Values": ["vpc"]}]
        )
    except (BotoCoreError, ClientError) as e:
        logger.error(f"Error fetching Transit Gateway Attachments: {e}")
        sys.exit(1)

def fetch_vpc_name_map(ec2_client: Any) -> Dict[str, str]:
    """
    Fetch VPCs and build a mapping of VPC ID to VPC name.
    Args:
        ec2_client: The EC2 client object.
    Returns:
        Dict[str, str]: A mapping of VPC IDs to their names.
    """
    try:
        vpcs = ec2_client.describe_vpcs()
        return {
            vpc["VpcId"]: next(
                (tag["Value"] for tag in vpc.get("Tags", []) if tag["Key"] == "Name"), "No Name"
            )
            for vpc in vpcs.get("Vpcs", [])
        }
    except (BotoCoreError, ClientError) as e:
        logger.error(f"Error fetching VPCs: {e}")
        sys.exit(1)

def display_transit_gateway_attachments(
    attachments: Dict[str, Any], vpc_name_map: Dict[str, str]
) -> None:
    """
    Display Transit Gateway Attachments with associated VPC names.
    Args:
        attachments (Dict[str, Any]): Transit Gateway Attachments data.
        vpc_name_map (Dict[str, str]): A mapping of VPC IDs to names.
    """
    header = (
        f"{Fore.LIGHTYELLOW_EX}{'TransitGatewayId':<20} "
        f"{Fore.LIGHTRED_EX}{'AttachmentId':<20} "
        f"{Fore.LIGHTBLUE_EX}{'VpcId':<15} "
        f"{Fore.LIGHTGREEN_EX}{'State':<10} "
        f"{Fore.LIGHTCYAN_EX}{'VpcName'}{Style.RESET_ALL}"
    )
    separator = Fore.LIGHTWHITE_EX + "-" * 80 + Style.RESET_ALL

    print(header)
    print(separator)

    for attachment in attachments.get("TransitGatewayAttachments", []):
        vpc_id = attachment.get("ResourceId", "Unknown")
        state_color = (
            Fore.LIGHTGREEN_EX if attachment.get("State") == "available" else Fore.LIGHTRED_EX
        )
        print(
            f"{Fore.LIGHTYELLOW_EX}{attachment.get('TransitGatewayId', 'Unknown'):<20} "
            f"{Fore.LIGHTRED_EX}{attachment.get('TransitGatewayAttachmentId', 'Unknown'):<20} "
            f"{Fore.LIGHTBLUE_EX}{vpc_id:<15} "
            f"{state_color}{attachment.get('State', 'Unknown'):<10} "
            f"{Fore.LIGHTCYAN_EX}{vpc_name_map.get(vpc_id, 'No Name')}{Style.RESET_ALL}"
        )

def main() -> None:
    """
    Main function to list Transit Gateway Attachments with VPC names.
    """
    args = parse_arguments()
    profile = args.profile

    session = initialize_session(profile)
    ec2 = session.client("ec2")

    attachments = fetch_transit_gateway_attachments(ec2)
    vpc_name_map = fetch_vpc_name_map(ec2)

    display_transit_gateway_attachments(attachments, vpc_name_map)

if __name__ == "__main__":
    main()

