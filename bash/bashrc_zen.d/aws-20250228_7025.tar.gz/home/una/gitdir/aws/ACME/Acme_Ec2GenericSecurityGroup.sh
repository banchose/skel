aws ec2 run-instances \
  --image-id ami-0abcdef1234567890 \
  --count 1 \
  --instance-type t2.micro \
  --key-name my-key-pair \
  --security-group-ids sg-0123456789abcdef0 \
  --subnet-id subnet-1234567890abcdef \
  --user-data '#!/bin/bash
yum update -y
yum install -y tmux
yum install -y git
yum install -y wireshark-cli
yum install -y nginx' \
  --region us-east-1 \
  -- profile lab3
