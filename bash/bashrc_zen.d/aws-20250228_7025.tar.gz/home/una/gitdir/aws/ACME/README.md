# Order of the stacks

- s3Endpoint: `pAcmeVpcId`, `pAcmeMainRouteTableId`
- AcmeSsmVpcEndpoints: `pAcmeVpcId`, `pAcmeSubnetId` per AZ
- AcmeLaunchTemplate: `pAcmeVpcId`
- AcmePrivateSubnet: `pAcmeVpcId`, `pAcmeInternetGatewayId`
- AcmeDhcpOptionsSet: `pAcmeVpcId`
- AcmeVpc: `pAcmeVpc` User provides VPC CIDR
