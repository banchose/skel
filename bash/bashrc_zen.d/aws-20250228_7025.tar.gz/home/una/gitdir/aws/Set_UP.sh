set_stack_outputs() {
  local stack_name="$1"
  local region="${2:-us-east-1}"
  local profile="${3:-default}"
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].Outputs" --output json --region "$region" --profile "$profile") || {
    echo "Error: Failed to retrieve stack outputs for '$stack_name'." 1>&2
    return 1
  }
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 1
  fi
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")
  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"
    export "$output_key=$output_value"
    echo "Exported $output_key=$output_value"
  done
}

set_stack_outputs HRI-BIGNETWORK us-east-1 net
sleep 2
set_stack_outputs HRI-BIGAWSDNS us-east-1 net
sleep 2
set_stack_outputs HRI-BIGDEV us-east-1 dev
sleep 2
set_stack_outputs HRI-BIGTEST us-east-1 test
