
cat star_healthresearch_org.crt DigiCertCA.crt TrustedRoot.crt > fullchain.pem

# Import to ACM
aws acm import-certificate \
    --certificate fileb://star_healthresearch_org.crt \
    --private-key fileb://star_healthresearch_org.key \
    --certificate-chain fileb://fullchain.pem \
    --profile test

1. **Parameters**:
- VPC ID, VPC CIDR, and Subnet ID are required inputs
- Health check timeout (default 10 seconds)
- Certificate ARN for TLS termination

2. **VPC Endpoints** ([aws.amazon.com/vpc](https://aws.amazon.com/vpc/)):
Creates interface endpoints for:
- ECR API and Docker
- CloudWatch Logs
- ECS Agent and Telemetry
- ECS service
These endpoints allow private communication with AWS services without going through the internet.

3. **Security Groups**:
- VPC Endpoint Security Group (allows 443)
- ECS Security Group (allows 80 and 443)
- NLB Security Group (allows 80 and 443)

4. **Load Balancer Setup**:
- Network Load Balancer in internal mode
- TLS Listener on port 443 with provided certificate
- TCP Listener on port 80
- Target group for container routing

5. **ECS Resources** ([aws.amazon.com/ec2](https://aws.amazon.com/ec2/)):
- ECS Cluster named "SimpleCluster"
- Fargate Task Definition running nginx
- ECS Service with desired count of 1
- Logging configuration to CloudWatch Logs

6. **IAM Roles**:
- Task Execution Role with ECS execution policy

Key Security Features:
- Private subnets (AssignPublicIp: DISABLED)
- TLS termination at NLB
- VPC endpoints for private AWS service access
- Security group restrictions

To update or create the stack, you're using:
```bash
# Update existing stack
aws cloudformation update-stack --stack-name ECS ...

# Or create new stack
aws cloudformation create-stack --stack-name ECS ...
```

For the TLS certificate, you're importing it to ACM:
```bash
# Combine certificates
cat star_healthresearch_org.crt DigiCertCA.crt TrustedRoot.crt > fullchain.pem

# Import to ACM
aws acm import-certificate \
    --certificate fileb://star_healthresearch_org.crt \
    --private-key fileb://star_healthresearch_org.key \
    --certificate-chain fileb://fullchain.pem \
    --profile test
```

1. **VPCEndpointSecurityGroup**
- Attached to: All VPC Endpoints (ECR API, ECR Docker, CloudWatch Logs, ECS Agent, ECS Telemetry, ECS)
- Allows:
```yaml
- Protocol: TCP
  Port: 443
  Source: VPC CIDR (pVpcCidr)
```

2. **ECSSecurityGroup**
- Attached to: ECS Fargate Tasks (via ECS Service's NetworkConfiguration)
- Allows:
```yaml
- Protocol: TCP
  Port: 80
  Source: VPC CIDR (pVpcCidr)
- Protocol: TCP
  Port: 443
  Source: VPC CIDR (pVpcCidr)
```

3. **NLBSecurityGroup**
- Attached to: Network Load Balancer
- Allows:
```yaml
- Protocol: TCP
  Port: 443
  Source: VPC CIDR (pVpcCidr)
- Protocol: TCP
  Port: 80
  Source: VPC CIDR (pVpcCidr)
```

According to [aws.amazon.com](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-security-groups.html), security groups are stateful, meaning return traffic is automatically allowed. Also, important to note that each security group here is scoped to private internal traffic only (VPC CIDR) which is a security best practice for internal services.

Visual Flow:
```
External -> NLB (NLBSecurityGroup)
            Port 80/443
                ↓
            ECS Tasks (ECSSecurityGroup)
            Port 80/443
                ↓
            VPC Endpoints (VPCEndpointSecurityGroup)
            Port 443
```

Best Practices Implemented:
- Following principle of least privilege
- All traffic restricted to VPC CIDR
- Clear separation of concerns between different components

