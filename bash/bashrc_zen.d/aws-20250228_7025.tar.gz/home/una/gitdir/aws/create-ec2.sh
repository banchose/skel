aws cloudformation create-stack \
  --stack-name MiniEc2Instance \
  --template-body file://./mini_Ec2Instance.yaml \
  --parameters ParameterKey="pMiniVpcId",ParameterValue="${rTestVpc}" \
  ParameterKey="pMiniEc2IamInstanceProfileId",ParameterValue="${rTestEc2IamInstanceProfileId}" \
  ParameterKey="pMiniPrivateSubnetId",ParameterValue="${rTestPrivateSubnet}" \
  ParameterKey="pAllowedIP",ParameterValue="108.44.37.87/32" \
  --region us-east-1 \
  --profile lab
