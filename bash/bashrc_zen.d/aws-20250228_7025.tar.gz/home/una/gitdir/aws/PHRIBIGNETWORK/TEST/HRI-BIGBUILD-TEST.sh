#!/usr/bin/env bash

set -euo pipefail

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGTEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGTEST \
  --capabilities CAPABILITY_NAMED_IAM \
  --template-body file://HRI-BIGTEST.yaml \
  --parameter ParameterKey="pInspectTransitGatewayId",ParameterValue="${rInspectTransitGateway}" \
  --disable-rollback \
  --region us-east-1 \
  --profile test

hang_fire HRI-BIGTEST test

# set_stack_outputs HRI-BIGNETWORK us-east-1 net
# set_stack_outputs HRI-BIGAWSDNS us-east-1 net
# set_stack_outputs HRI-BIGDEV us-east-1 dev
# set_stack_outputs HRI-BIGTEST us-east-1 test

echo ""
echo "***********************************"
echo ""
echo " Transit Gateway association TEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-TGWRT-ASSC-TEST \
  --template-body file://HRI-BIGNETWORK-TGWRT-ASSC-TEST.yaml \
  --parameters ParameterKey="pTestTransitGatewayAttachmentId",ParameterValue="${rTestTransitVpcAttachment}" \
  ParameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${rInspectTransitGatewayRouteTable}" \
  --disable-rollback \
  --region us-east-1 \
  --profile net

hang_fire HRI-BIGNETWORK-TGWRT-ASSC-TEST net

echo ""
echo "***********************************"
echo ""
echo " Forwarder Resource Rule TEST"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGTEST-FRD-RR-DNS \
  --template-body file://HRI-BIGTEST-FRD-RR-DNS.yaml \
  --parameter ParameterKey="pTestVpcId",ParameterValue="${rTestVpc}" \
  ParameterKey="pTestWorkloadPrivateSubnetId",ParameterValue="${rTestWorkloadPrivateSubnet}" \
  ParameterKey="pTestTransitPrivateSubnetId",ParameterValue="${rTestTransitPrivateSubnet}" \
  ParameterKey="pSharedResolverRuleForwardId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDns}" \
  ParameterKey="pSharedResolverRuleReverseId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDnsRev}" \
  --disable-rollback \
  --region us-east-1 \
  --profile test

hang_fire HRI-BIGTEST-FRD-RR-DNS test
echo ""
echo "***********************************"
echo ""
echo " Associating Hosted Zone with TEST"
echo ""
echo "***********************************"
echo ""

./HRI-BIGTEST-ASSC-HOSTZONE-TEST.sh
