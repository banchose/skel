aws ec2 describe-instances \
  --filters "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].{
    Name: Tags[?Key==`Name`].Value | [0],
    InstanceId: InstanceId,
    Type: InstanceType,
    AZ: Placement.AvailabilityZone,
    PublicIP: PublicIpAddress || `No Public IP`,
    PrivateIP: PrivateIpAddress
  }' \
  --output table \
  --profile net
