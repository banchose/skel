# aws ec2 describe-instances \
#   --instance-ids i-1234567890abcdef0 \
#   --query 'Reservations[*].Instances[*].PublicIpAddress' \
#   --output text \
#   --region us-east-1

#
# Set ssh user
#
user=wjs04
# user=una

# function to export outputs to the env
set_stack_outputs() {

  local stack_name="$1"
  local region="${2:-us-east-1}"
  local profile="${3:-default}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Error: Failed to retrieve stack outputs for '$stack_name'." >&2
    return 1
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 1
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done

}

set_stack_outputs unit1 us-east-1 net
# This will use one of the envs from the set_stack_outputs: Unit1Ec2InstancePublicIp
ssh ${user}@"${Unit1Ec2InstancePublicIp}"
