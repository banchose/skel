aws route53 list-resource-record-sets \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --profile net \
  --query "ResourceRecordSets[?Type=='A']"
