# set_stack_outputs HRI-BIGNETWORK us-east-1 net
#
echo "rInspectvMXSubnetRouteTableAZB: ${rInspectvMXSubnetRouteTableAZB}"
echo "rInspectvMXInstanceAZB: ${rInspectvMXInstanceAZB}"

# aws ec2 create-route \
#   --route-table-id "${rInspectvMXSubnetRouteTableAZB}" \
#   --destination-cidr-block 10.0.0.0/8 \
#   --instance-id "${rInspectvMXInstanceAZB}" \
#   --region us-east-1 \
#   --profile net
