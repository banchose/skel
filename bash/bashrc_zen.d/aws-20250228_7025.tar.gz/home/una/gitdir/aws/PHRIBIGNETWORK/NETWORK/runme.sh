./copy-netyaml-to-s3.sh
aws cloudformation update-stack \
  --stack-name v2-HRI-BIGNETWORK \
  --template-url https://hri-cloudformation-templates-211262586138-us-east-1.s3.us-east-1.amazonaws.com/network/v2-HRI-BIGNETWORK.yaml \
  --capabilities CAPABILITY_IAM \
  --parameters ParameterKey="pInspectvMXToken",ParameterValue="be4d35956223a5522131f364d83d5365/9669b0ed96b4ac9836e4bd426bda09c0f5b572ac99cd00added3bba25780780959138f9d55fd823118dfbc0452612a8582b0f71e4bb827a354335c7a3bcd9039/b45352b6227ae0274cb1bbcd16ba7eabe9d7c3649e07ef379b857d0ced322f11" \
  ParameterKey="pInspectvMXTokenAZB",ParameterValue="5055ee36e9afa6e22b995860d01cf8d9/f5a161b081faba1ed03de0d9bd61ce69df4b32c88a1ec59fa7173d4c18a602bac9cd3a4b0ce5654dc0ecdecfe22383e18b0d335af2027fc56f7c7dd9704a165f/85fb2e2f3b2e454b31385face618552d7ae8cc6be2ccc9932f70dd84cd363597" \
  --disable-rollback \
  --region us-east-1 \
  --profile net
