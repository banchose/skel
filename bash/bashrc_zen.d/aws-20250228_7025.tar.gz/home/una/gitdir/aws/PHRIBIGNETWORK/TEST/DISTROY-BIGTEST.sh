#!/usr/bin/env bash

set -xuo pipefail

aws cloudformation delete-stack --stack-name HRI-BIGNETWORK-TGWRT-ASSC-TEST --region us-east-1 --profile net
aws cloudformation delete-stack --stack-name HRI-BIGTEST-FRD-RR-DNS --region us-east-1 --profile test
sleep 30
aws cloudformation delete-stack --stack-name HRI-BIGTEST --region us-east-1 --profile test
