aws ec2 delete-route \
  --route-table-id "${rInspectvMXSubnetRouteTable}" \
  --destination-cidr-block 10.0.0.0/8 \
  --region us-east-1 \
  --profile net
