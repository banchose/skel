#!/usr/bin/env bash

# Exit on error, undefined vars, and propagate pipe failures
set -euo pipefail
IFS=$'\n\t'

echo "Fetching all VPCs and their route tables..."
echo "==========================================="

# Get all VPCs and split them properly
readarray -t vpcs < <(aws ec2 describe-vpcs --profile net --region us-east-1 --query 'Vpcs[*].VpcId' --output text | tr '\t' '\n')

for vpc in "${vpcs[@]}"; do
  # Skip empty entries
  [[ -z "${vpc}" ]] && continue

  echo "VPC: ${vpc}"
  # Get VPC name tag if it exists
  vpc_name=$(aws ec2 describe-vpcs --vpc-ids "${vpc}" --profile net --region us-east-1 --query "Vpcs[*].Tags[?Key=='Name'].Value" --output text)
  echo "VPC Name: ${vpc_name}"
  echo "-------------------------------------------"

  # Get route tables for this VPC
  readarray -t route_tables < <(aws ec2 describe-route-tables --filters "Name=vpc-id,Values=${vpc}" --profile net --region us-east-1 --query 'RouteTables[*].RouteTableId' --output text | tr '\t' '\n')

  for rt in "${route_tables[@]}"; do
    # Skip empty entries
    [[ -z "${rt}" ]] && continue

    echo "Route Table: ${rt}"
    echo "==============================================="

    # Get tags
    echo "Tags:"
    aws ec2 describe-route-tables --route-table-ids "${rt}" --profile net --region us-east-1 --query 'RouteTables[*].Tags' --output table

    # Get routes
    echo "Routes:"
    aws ec2 describe-route-tables --route-table-ids "${rt}" --profile net --region us-east-1 --query 'RouteTables[*].Routes' --output table

    # Get associations
    echo "Associations:"
    aws ec2 describe-route-tables --route-table-ids "${rt}" --profile net --region us-east-1 --query 'RouteTables[*].Associations' --output table

    echo $'\n'
  done
  echo $'\n'
done

# Also get Transit Gateway route tables
echo "Transit Gateway Route Tables:"
echo "==========================================="
readarray -t tgw_route_tables < <(aws ec2 describe-transit-gateway-route-tables --profile net --region us-east-1 --query 'TransitGatewayRouteTables[*].TransitGatewayRouteTableId' --output text | tr '\t' '\n')

for tgw_rt in "${tgw_route_tables[@]}"; do
  # Skip empty entries
  [[ -z "${tgw_rt}" ]] && continue

  echo "TGW Route Table: ${tgw_rt}"
  echo "==============================================="

  # Get TGW routes
  aws ec2 search-transit-gateway-routes --transit-gateway-route-table-id "${tgw_rt}" --filters "Name=type,Values=static,propagated" --profile net --region us-east-1 --output table

  echo $'\n'
done
