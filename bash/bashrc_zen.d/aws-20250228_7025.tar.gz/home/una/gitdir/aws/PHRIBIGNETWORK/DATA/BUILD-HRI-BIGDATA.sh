#!/usr/bin/env bash

set -euo pipefail

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=10

  ## Wait for net to finish
  echo "Hang Fire ${StackName} ${StackProfile}"
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

set_stack_outputs HRI-BIGNETWORK us-east-1 net
set_stack_outputs HRI-BIGAWSDNS us-east-1 net

echo "####===> BUILDING HRI-BIGDATA <===###"

aws cloudformation create-stack \
  --stack-name HRI-BIGDATA \
  --capabilities CAPABILITY_NAMED_IAM \
  --template-body file://./HRI-BIGDATA.yaml \
  --parameter ParameterKey="pInspectTransitGatewayId",ParameterValue="${rInspectTransitGateway}" \
  --region us-east-1 \
  --profile production

sleep 5
hang_fire HRI-BIGDATA production

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK-TGWRT-ASSC-DATA \
  --template-body file://./HRI-BIGNETWORK-TGWRT-ASSC-DATA.yaml \
  --parameters ParameterKey="pDataTransitGatewayAttachmentId",ParameterValue="${rDataTransitVpcAttachment}" \
  ParameterKey="pInspectTransitGatewayRouteTableId",ParameterValue="${rInspectTransitGatewayRouteTable}" \
  --region us-east-1 \
  --profile net

sleep 5
hang_fire HRI-BIGNETWORK-TGWRT-ASSC-DATA net

aws cloudformation create-stack \
  --stack-name HRI-BIGDATA-FRD-RR-DNS \
  --template-body file://./HRI-BIGDATA-FRD-RR-DNS.yaml \
  --parameter ParameterKey="pDataVpcId",ParameterValue="${rDataVpc}" \
  ParameterKey="pDataWorkloadPrivateSubnetId",ParameterValue="${rDataWorkloadPrivateSubnet}" \
  ParameterKey="pDataTransitPrivateSubnetId",ParameterValue="${rDataTransitPrivateSubnet}" \
  ParameterKey="pSharedResolverRuleForwardId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDns}" \
  ParameterKey="pSharedResolverRuleReverseId",ParameterValue="${rPrivateHostedZoneForwardingRuleHriAdDnsRev}" \
  --region us-east-1 \
  --profile production

sleep 5
hang_fire HRI-BIGDATA-FRD-RR-DNS production

./HRI-BIGDATA-ASSC-HOSTZONE-PRODUCTION.sh
