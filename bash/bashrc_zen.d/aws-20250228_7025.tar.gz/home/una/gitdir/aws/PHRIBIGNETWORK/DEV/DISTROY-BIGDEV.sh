#!/usr/bin/env bash

set -xuo pipefail

aws cloudformation delete-stack --stack-name HRI-BIGNETWORK-TGWRT-ASSC-DEV --region us-east-1 --profile net
aws cloudformation delete-stack --stack-name HRI-BIGDEV-FRD-RR-DNS --region us-east-1 --profile dev
sleep 30
aws cloudformation delete-stack --stack-name HRI-BIGDEV --region us-east-1 --profile dev
