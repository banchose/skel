#!/usr/bin/env bash

set -euo pipefail

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rTestVpc}" \
  --region us-east-1 \
  --profile net

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rTestVpc}" \
  --region us-east-1 \
  --profile net

sleep 60

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rTestVpc}" \
  --region us-east-1 \
  --profile test

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rTestVpc}" \
  --region us-east-1 \
  --profile test
