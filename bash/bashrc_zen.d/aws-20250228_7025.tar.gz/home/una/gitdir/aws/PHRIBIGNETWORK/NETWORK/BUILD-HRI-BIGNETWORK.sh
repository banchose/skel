#!/usr/bin/env bash

set -euo pipefail

BucketName="hri-cloudformation-templates-net-useast1-net"
Template="HRI-BIGNETWORK.yaml"
TemplateURL="https://s3.amazonaws.com/hri-cloudformation-templates-net-useast1/network/HRI-BIGNETWORK.yaml"
StackName=HRI-BIGNETWORK
Region=us-east-1

aws s3 cp ./"${Template}" s3://"${BucketName}"/network/"${Template##*/}" \
  --region us-east-1 \
  --profile net

## Set vMX key or there will be tears
pInspectvMXToken=""
# Duplicate from set from a file containing helpful aws bas functions
# Needed to make sure set_stack_outputs was available so it is here 'inline'
set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

echo ""
echo "***********************************"
echo ""
echo " Building HRI-BIGNETWORK"
echo ""
echo "***********************************"
echo ""

aws cloudformation create-stack \
  --stack-name HRI-BIGNETWORK \
  --template-url "${TemplateURL}" \
  --capabilities CAPABILITY_IAM \
  --parameters ParameterKey="pInspectvMXToken",ParameterValue="FILLME" \
  ParameterKey="pInspectvMXTokenAZB",ParameterValue="FILLME" \
  --disable-rollback \
  --region "${Region}" \
  --profile net

hang_fire HRI-BIGNETWORK net
