#!/usr/bin/env bash
set -xeuo pipefail

Profile=net
Region=us-east-1
StackName="CfTemplateBucketCreate"
BucketTemplate=/home/una/aws/HRIBIGNETWORK/CREATE-S3-CF-TEMPLATE-BUCKET.yaml
NetworkTemplate=/home/una/aws/HRIBIGNETWORK/HRI-BIGNETWORK.yaml
BucketName="hri-cloudformation-templates-${AWS::AccountId}-${AWS::Region}"

# Check if required files exist
[[ -f "${NetworkTemplate}" ]] || {
  echo "Network template file not found: ${NetworkTemplate}"
  exit 1
}
[[ -f "${BucketTemplate}" ]] || {
  echo "Bucket template file not found: ${BucketTemplate}"
  exit 1
}

# Deploy the CloudFormation template that creates the bucket
aws cloudformation deploy \
  --template-file "${BucketTemplate}" \
  --stack-name "${StackName}" \
  --profile "${Profile}" \
  --region "${Region}"

# Get the bucket name from CloudFormation outputs
BucketName=$(aws cloudformation describe-stacks \
  --stack-name "${StackName}" \
  --query 'Stacks[0].Outputs[?OutputKey==`TemplateBucketName`].OutputValue' \
  --output text \
  --profile "${Profile}" \
  --region "${Region}")

# Copy the network template to the newly created bucket
aws s3 cp "${NetworkTemplate}" "s3://${BucketName}/network/${NetworkTemplate##*/}" \
  --region "${Region}" \
  --profile "${Profile}"
