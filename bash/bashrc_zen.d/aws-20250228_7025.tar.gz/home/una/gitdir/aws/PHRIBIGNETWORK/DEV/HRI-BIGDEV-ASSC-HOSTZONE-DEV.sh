#!/usr/bin/env bash

set -euo pipefail

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDevVpc}" \
  --region us-east-1 \
  --profile net

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDevVpc}" \
  --region us-east-1 \
  --profile net

sleep 10

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDevVpc}" \
  --region us-east-1 \
  --profile dev

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDevVpc}" \
  --region us-east-1 \
  --profile dev
