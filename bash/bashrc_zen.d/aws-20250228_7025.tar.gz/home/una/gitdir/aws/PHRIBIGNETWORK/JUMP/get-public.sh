#!/usr/bin/bash

set -euo pipefail

aws ec2 describe-instances \
  --filters "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].[Tags[?Key==`Name`].Value | [0], PublicIpAddress]' \
  --output table \
  --region us-east-1 \
  --profile net

# aws ec2 describe-instances \
#  --query 'Reservations[*].Instances[*].[Tags[?Key==`Name`].Value | [0], PublicIpAddress]' \
#  --filters "Name=tag:Name,Values=myhost" \
#  --output text \
#   --profile net

# To get both the PublicIpAddress and hostname (assuming you mean the Name tag), you can modify the query like this:
#
# ```bash
# aws ec2 describe-instances \
#   --query 'Reservations[*].Instances[*].[Tags[?Key==`Name`].Value | [0], PublicIpAddress]' \
#   --output text \
#   --profile net
# ```
#
# To filter for a specific hostname "myhost":
#
# ```bash
# aws ec2 describe-instances \
#   --query 'Reservations[*].Instances[*].[Tags[?Key==`Name`].Value | [0], PublicIpAddress]' \
#   --filters "Name=tag:Name,Values=myhost" \
#   --output text \
#   --profile net
# ```
#
# A few notes and alternative approaches:
#
# 1. If you prefer JSON output for better parsing:
# ```bash
# --output json
# ```
#
# 2. You could also use jq for more flexible filtering:
# ```bash
# aws ec2 describe-instances --profile net --output json | \
#   jq -r '.Reservations[].Instances[] | select(.Tags[].Value=="myhost") | .PublicIpAddress'
# ```
#
# 3. If you're dealing with private hostnames instead of Name tags, you might want:
# ```bash
# --query 'Reservations[*].Instances[*].[PrivateDnsName,PublicIpAddress]'
# ```
#
