#!/usr/bin/env bash

set -euo pipefail

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

set_stack_outputs HRI-BIGAWSDNS us-east-1 net
set_stack_outputs HRI-BIGDATA us-east-1 production

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDataVpc}" \
  --region us-east-1 \
  --profile net

aws route53 create-vpc-association-authorization \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDataVpc}" \
  --region us-east-1 \
  --profile net

sleep 60

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZone}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDataVpc}" \
  --region us-east-1 \
  --profile production

aws route53 associate-vpc-with-hosted-zone \
  --hosted-zone-id "${rHriAwsPrivateHostedZoneRev}" \
  --vpc VPCRegion=us-east-1,VPCId="${rDataVpc}" \
  --region us-east-1 \
  --profile production
