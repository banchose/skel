# aws ec2 describe-transit-gateway-attachments \
#   --filters "Name=state,Values=pending,available" "Name=resource-type,Values=vpc" \
#   --query "TransitGatewayAttachments[?starts_with(ResourceId, 'vpc-')].TransitGatewayAttachmentId | [0]" \
#   --output text \
#   --region us-east-1 \
#   --profile test
#
# # 1. Associate the TGW attachment with the route table
# aws ec2 associate-transit-gateway-route-table \
#   --transit-gateway-attachment-id tgw-attach-02fa1a3aa6a7bfed1 \
#   --transit-gateway-route-table-id "${rInspectTransitGatewayRouteTable}" \
#   --region us-east-1 \
#   --profile net
#
# # 2. Add a route for the EKS VPC CIDR
# aws ec2 create-transit-gateway-route \
#   --transit-gateway-route-table-id "${rInspectTransitGatewayRouteTable}" \
#   --destination-cidr-block 172.22.160.0/20 \
#   --transit-gateway-attachment-id tgw-attach-02fa1a3aa6a7bfed1 \
#   --region us-east-1 \
#   --profile net
# #!/usr/bin/env bash
set -euo pipefail

# Set variables
REGION="us-east-1"
SOURCE_PROFILE="test"
NETWORK_PROFILE="net"
TGW_ROUTE_TABLE_ID="${rInspectTransitGatewayRouteTable}"
EKS_VPC_CIDR="172.22.160.0/20"

echo "🔍 Finding Transit Gateway attachment..."

# Get the Transit Gateway Attachment ID
TGW_ATTACHMENT_ID=$(aws ec2 describe-transit-gateway-attachments \
  --filters "Name=state,Values=pending,available" "Name=resource-type,Values=vpc" \
  --query "TransitGatewayAttachments[?starts_with(ResourceId, 'vpc-')].TransitGatewayAttachmentId | [0]" \
  --output text \
  --region $REGION \
  --profile $SOURCE_PROFILE)

# Check if we found an attachment ID
if [[ -z "$TGW_ATTACHMENT_ID" || "$TGW_ATTACHMENT_ID" == "None" ]]; then
  echo "❌ Error: Could not find a Transit Gateway attachment. Exiting."
  exit 1
fi

echo "✅ Found Transit Gateway attachment: $TGW_ATTACHMENT_ID"

# 1. Associate the TGW attachment with the route table
echo "🔄 Associating Transit Gateway attachment with route table..."
aws ec2 associate-transit-gateway-route-table \
  --transit-gateway-attachment-id "$TGW_ATTACHMENT_ID" \
  --transit-gateway-route-table-id "$TGW_ROUTE_TABLE_ID" \
  --region $REGION \
  --profile $NETWORK_PROFILE

# 2. Add a route for the EKS VPC CIDR
echo "🔄 Creating Transit Gateway route for $EKS_VPC_CIDR..."
aws ec2 create-transit-gateway-route \
  --transit-gateway-route-table-id "$TGW_ROUTE_TABLE_ID" \
  --destination-cidr-block "$EKS_VPC_CIDR" \
  --transit-gateway-attachment-id "$TGW_ATTACHMENT_ID" \
  --region $REGION \
  --profile $NETWORK_PROFILE

echo "✅ Transit Gateway configuration complete!"

# Optional: Verify the association and route
echo "🔍 Verifying configuration..."

# Check association
ASSOCIATION_STATE=$(aws ec2 get-transit-gateway-route-table-associations \
  --transit-gateway-route-table-id "$TGW_ROUTE_TABLE_ID" \
  --query "Associations[?TransitGatewayAttachmentId=='$TGW_ATTACHMENT_ID'].State" \
  --output text \
  --region $REGION \
  --profile $NETWORK_PROFILE)

if [[ "$ASSOCIATION_STATE" == "associated" ]]; then
  echo "✅ Route table association verified."
else
  echo "⚠️ Warning: Route table association not verified. State: $ASSOCIATION_STATE"
fi

echo "📋 Configuration summary:"
echo "- Transit Gateway attachment: $TGW_ATTACHMENT_ID"
echo "- Transit Gateway route table: $TGW_ROUTE_TABLE_ID"
echo "- EKS VPC CIDR: $EKS_VPC_CIDR"
