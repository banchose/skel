# Ballpark EKS Cost Breakdown

## Control Plane Costs

You're right about the EKS control plane cost:
- **$73-$96 per month** ($0.10 per hour) for each EKS cluster, depending on the region
- This is a fixed cost regardless of cluster size

## Node Costs (Ballpark Estimates)

Node costs vary significantly based on:
1. Instance type
2. Region
3. Pricing model (On-Demand vs Reserved vs Spot)
4. Number of nodes

Here are some common scenarios:

### Small Development Cluster
- **t3.medium** (2 vCPU, 4 GB RAM): ~$30-40/month per node
- With 2 nodes: ~$60-80/month

### Medium Production Cluster
- **m5.large** (2 vCPU, 8 GB RAM): ~$70-90/month per node
- With 3 nodes: ~$210-270/month

### Larger Production Cluster
- **c5.2xlarge** (8 vCPU, 16 GB RAM): ~$250-300/month per node
- With 4 nodes: ~$1,000-1,200/month

According to [spot.io](https://spot.io/resources/aws-eks/understanding-eks-pricing/), worker nodes typically account for 80-90% of your total EKS costs.

## Cost-Saving Options

1. **Spot Instances**: Save 70-90% compared to On-Demand prices
   - Good for non-critical workloads
   - Requires handling interruptions

2. **Reserved Instances**: Save 40-60% with 1-3 year commitments
   - Good for predictable, stable workloads

3. **Graviton Instances** (ARM-based): Save 20-40% compared to x86 equivalents
   - Requires ARM-compatible containers

## Total Monthly Cost Example

For a typical small production cluster:
- Control plane: ~$73-96/month
- 3x t3.large nodes On-Demand: ~$240-300/month
- **Total: ~$313-396/month**

For a medium production cluster:
- Control plane: ~$73-96/month
- 3x m5.large nodes On-Demand: ~$210-270/month
- **Total: ~$283-366/month**

## Additional Costs to Consider

Don't forget these additional costs that can add up:

1. **EBS volumes**: ~$0.10/GB per month for gp2 volumes
2. **Load Balancers**: ~$20-25/month per ALB
3. **Data Transfer**: ~$0.09/GB for outbound traffic
4. **Snapshots/Backups**: Variable based on size and frequency

As [cloudzero.com](https://www.cloudzero.com/blog/eks-pricing/) notes, container costs can "quickly add up depending on usage" and introduce "cost blindspots" if not carefully monitored.

Compared to self-managed Kubernetes or other managed Kubernetes services like GKE, EKS has a higher fixed control plane cost but competitive node pricing, especially if you leverage cost-optimization strategies.
