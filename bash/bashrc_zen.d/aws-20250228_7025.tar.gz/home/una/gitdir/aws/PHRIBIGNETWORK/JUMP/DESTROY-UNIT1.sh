#!/usr/bin/env bash

### NOTE
# MAKE SURE YOU HAVE THE LATEST aws commands from head ./*.yaml
# And that they are being used below
# :r head -n 20 ./template.yaml
# At the top of the yaml files

set -xuo pipefail

StackName=unit1

echo "rInspectVpc:   ${rInspectVpc}"
echo "rInspectvMXPublicSubnet:   ${rInspectvMXPublicSubnet}"
echo "rInspectvMXInstance: ${rInspectvMXInstance}"
echo "rInspectvMXSubnetRouteTable: ${rInspectvMXSubnetRouteTable}"

set_stack_outputs() {
  local stack_name="$1"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

  sleep 5

}

set_stack_outputs HRI-BIGNETWORK us-east-1 net

aws cloudformation delete-stack \
  --stack-name "${StackName}" \
  --region us-east-1 \
  --profile net

# set_stack_outputs HRI-BIGNETWORK us-east-1 net

# This deletes route that unit1 put in to get to on-prem
aws ec2 delete-route \
  --route-table-id "${rInspectvMXSubnetRouteTable}" \
  --destination-cidr-block 10.0.0.0/8 \
  --region us-east-1 \
  --profile net
