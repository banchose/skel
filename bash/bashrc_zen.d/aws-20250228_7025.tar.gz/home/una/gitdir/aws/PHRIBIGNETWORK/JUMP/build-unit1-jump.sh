#!/usr/bin/env bash

### NOTE
# MAKE SURE YOU HAVE THE LATEST aws commands from head ./*.yaml
# And that they are being used below
# :r head -n 20 ./template.yaml
# At the top of the yaml files

set -euo pipefail

[[ -n "${rInspectVpc}" ]] || {
  echo "ERROR: rInspectVpc is not defined"
  exit 1
}
[[ -n "${rInspectvMXPublicSubnet}" ]] || {
  echo "ERROR: rInspectvMXPublicSubnet is not defined"
  exit 1
}
[[ -n "${rInspectvMXInstance}" ]] || {
  echo "ERROR: rInspectvMXInstance is not defined"
  exit 1
}
[[ -n "${rInspectvMXSubnetRouteTable}" ]] || {
  echo "ERROR: rInspectvMXSubnetRouteTable is not defined"
  exit 1
}

# If we reach here, all variables are defined, so echo them
echo "rInspectVpc: ${rInspectVpc}"
echo "rInspectvMXPublicSubnet: ${rInspectvMXPublicSubnet}"
echo "rInspectvMXInstance: ${rInspectvMXInstance}"
echo "rInspectvMXSubnetRouteTable: ${rInspectvMXSubnetRouteTable}"

set_stack_outputs() {
  local stack_name="${1}"
  local region="${2}"
  local profile="${3}"

  # Get all stack outputs
  local outputs_json
  outputs_json=$(aws cloudformation describe-stacks \
    --stack-name "$stack_name" \
    --query "Stacks[0].Outputs" \
    --output json \
    --region "$region" \
    --profile "$profile") || {
    echo "Did not retrieve stack outputs for '$stack_name'." >&2
  }

  # Check if the outputs JSON is empty
  if [[ -z "$outputs_json" || "$outputs_json" == "[]" || "$outputs_json" == "null" ]]; then
    echo "No outputs found for stack: $stack_name"
    return 0
  fi

  # Parse outputs using a Bash array
  local output_key output_value
  mapfile -t outputs < <(jq -r '.[] | "\(.OutputKey) \(.OutputValue)"' <<<"$outputs_json")

  for line in "${outputs[@]}"; do
    output_key="${line%% *}"
    output_value="${line#* }"

    # Export with a prefix to avoid namespace collisions
    export "$output_key=$output_value"

    # Print for verification (optional)
    echo "Exported $output_key=$output_value"
  done
}

hang_fire() {
  local StackName="$1"
  local StackProfile="$2"
  local WaitTime=30

  ## Wait for net to finish
  aws cloudformation wait stack-create-complete \
    --stack-name "${StackName}" \
    --region us-east-1 --profile "${StackProfile}"

  echo "Just completed ${StackName}"

  echo "Waiting for ${WaitTime}"

  sleep "${WaitTime}"

  set_stack_outputs "${StackName}" us-east-1 "${StackProfile}"

}

set_stack_outputs HRI-BIGNETWORK us-east-1 net

### NOTE
# MAKE SURE YOU HAVE THE LATEST aws commands from head ./*.yaml
# And that they are being used below
# :r head -n 20 ./template.yaml
# At the top of the yaml files

# :r !head -n 15 ./jump-box-unit1.yaml

aws cloudformation create-stack \
  --stack-name unit1 \
  --template-body file://jump-box-unit1.yaml \
  --parameters ParameterKey="pVpcId",ParameterValue="${rInspectVpc}" \
  ParameterKey="pSubnetId",ParameterValue="${rInspectvMXPublicSubnetAZB}" \
  ParameterKey="pInspectvMXInstance",ParameterValue="${rInspectvMXInstance}" \
  ParameterKey="pInspectvMXSubnetRouteTable",ParameterValue="${rInspectvMXSubnetRouteTable}" \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --profile net

# --disable-rollback

hang_fire unit1 net

# set_stack_outputs HRI-BIGNETWORK us-east-1 net

# This creates a route that will need to be REMOVED
# Check if route exists already

EXISTING_ROUTE=$(aws ec2 describe-route-tables \
  --route-table-id "${rInspectvMXSubnetRouteTable}" \
  --region us-east-1 \
  --profile net \
  --query 'RouteTables[0].Routes[?DestinationCidrBlock==`10.0.0.0/8` && InstanceId==`'"${rInspectvMXInstance}"'`]' \
  --output json)

# Only create the route if it doesn't exist already
if [ "$EXISTING_ROUTE" == "[]" ]; then
  echo "Route doesn't exist. Creating now..."
  aws ec2 create-route \
    --route-table-id "${rInspectvMXSubnetRouteTable}" \
    --destination-cidr-block 10.0.0.0/8 \
    --instance-id "${rInspectvMXInstance}" \
    --region us-east-1 \
    --profile net
else
  echo "Route already exists. Skipping creation."
fi
