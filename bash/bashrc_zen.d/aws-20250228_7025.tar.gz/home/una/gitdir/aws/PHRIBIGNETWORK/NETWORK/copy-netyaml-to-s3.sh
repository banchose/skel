#!/usr/bin/env bash
set -xeuo pipefail

Profile=net
Region=us-east-1
BucketTemplate=/home/una/aws/PHRIBIGNETWORK/NETWORK/CREATE-S3-CF-TEMPLATE-BUCKET.yaml
NetworkTemplate=/home/una/aws/PHRIBIGNETWORK/NETWORK/HRI-BIGNETWORK.yaml
BucketName="hri-cloudformation-templates-211262586138-us-east-1"

# Check if required files exist
[[ -f "${NetworkTemplate}" ]] || {
  echo "Network template file not found: ${NetworkTemplate}"
  exit 1
}
[[ -f "${BucketTemplate}" ]] || {
  echo "Bucket template file not found: ${BucketTemplate}"
  exit 1
}
# Copy the network template to the newly created bucket
aws s3 cp "${NetworkTemplate}" "s3://${BucketName}/network/${NetworkTemplate##*/}" \
  --region "${Region}" \
  --profile "${Profile}"
