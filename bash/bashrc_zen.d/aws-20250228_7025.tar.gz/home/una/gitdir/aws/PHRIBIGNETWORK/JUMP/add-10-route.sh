# set_stack_outputs HRI-BIGNETWORK us-east-1 net
aws ec2 create-route \
  --route-table-id "${rInspectvMXSubnetRouteTable}" \
  --destination-cidr-block 10.0.0.0/8 \
  --instance-id "${rInspectvMXInstance}" \
  --region us-east-1 \
  --profile net
