export AwsRegion=us-east-1
export pSpoke1VpcId=vpc-0366b7aa344c780c2
export pSpoke2VpcId=vpc-0e7dc8e74f5691dec
export pInspectFirewallSubnetId=subnet-03bb9467a93faaf56
export pInspectTransitGatewaySubnetId=subnet-01b6cfa298e04223d
export pMiniSubnetId="subnet-0a36687268c1534c8"
export pMiniRouteTableId="rtb-01762bcc3183f125f"
export pMiniPrivateSubnetId="subnet-0a36687268c1534c8"
export MiniVpc="vpc-0e02be1c618a5afc5"
export MiniVpcId="vpc-0e02be1c618a5afc5"
export pMiniEc2IamInstanceProfileId="MiniVpc-rMiniSsmEc2InstanceProfile-0UCIzrft4g3b"
export pMiniVpcId="vpc-0e02be1c618a5afc5"
export pMiniEc2LaunchTemplateId:VpcId=vpc-0e02be1c618a5afc5
export pMiniPublicSubnetId="subnet-0f85517990b17aace"
export pSingleIp="108.44.37.87"
export pMiniEc2LaunchTemplateId="lt-013fadfd8c6df4307"
export pSingleIp="108.44.37.87/32"

