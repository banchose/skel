code .
aws sso login --profile lab
aws s3 ls --profile lab
sudo apt install shellcheck
aws ec2 describe-subnets --filters "Name=vpc-id,Values=vpc-00cc9f6d1ca20def3" --query "Subnets[*].SubnetId" --output text --profile lab --region us-east-1
 
git push --set-upstream origin addec2tossm 
  

aws cloudformation describe-stacks \
    --stack-name hri-MAIN \
    --region us-east-1 \
    --profile lab \
    --query "Stacks[0].StackStatus"
aws cloudformation create-change-set   --stack-name hri-MAIN    --template-body file://./hri-MAIN-inspect.yaml   --change-set-name my-change-set   --capabilities CAPABILITY_IAM --profile lab

aws cloudformation create-stack   --stack-name hri-MAIN    --template-body file://./hri-MAIN-inspect.yaml   --capabilities CAPABILITY_IAM --profile lab
 
aws cloudformation create-stack   --stack-name ssm-eps   --template-body file://./CF-AWS-SSM-EC2-Endpoints.yaml   --region us-east-1   --profile lab --parameters ParameterKey=SubnetIds,ParameterValue=subnet-01d20465293069765 --capabilities CAPABILITY_IAM

aws ec2 modify-instance-attribute --instance-id i-xxxxxxxxxxxxxxx --source-dest-check "{\"Value\": false}"
aws ec2 modify-instance-attribute --instance-id i-0351e695065425f0e --source-dest-check "{\"Value\": false}"

aws cloudformation create-stack   --stack-name hri-MAIN   --template-body file://./hri-MAIN-inspect.yaml   --region us-east-1   --profile lab --capabilities CAPABILITY_IAM --parameters ParameterKey="pInspectvMXToken",ParameterValue="fdaa0bd50a0c5497e7a28815e86ec193/a8d63f77a4fc9a5c03aa0a53b2f3fc31298b5b84e1c1b47582edcece7234d0f8b335e1a45063d574d167a5e19c6fc4b9bb7370a50109ab736428e3a97683d763/cf9975fe77bcd19ea1a41eefacce21fc4bd8064614c8c1ae6edfdcc46fed5257"
aws cloudformation create-stack   --stack-name hri-flowlogs   --template-body file://./flowlogs-example.yaml   --region us-east-1   --profile lab --capabilities CAPABILITY_NAMED_IAM

# List EC2 Instances
 aws ec2 describe-instances --query "Reservations[*].Instances[*].[InstanceId, Tags[?Key=='Name'].Value | [0], State.Name]" --output table

# Get Private IP Address
aws ec2 describe-instances --instance-ids i-095b837593c5a5fa6 --query "Reservations[*].Instances[*].PrivateIpAddress" --output text

# Get Public IP Address
aws ec2 describe-instances --instance-ids <instance-id> --query "Reservations[*].Instances[*].PublicIpAddress" --output text


 



When I added the vMX to lab, I set it to concentrator mode (required if acting as vMX) and I manually added a network to enable the vpn on and associated it with a hub




aws cloudformation create-change-set   --stack-name hri-MAIN    --template-body file://./hri-MAIN-inspect.yaml   --change-set-name my-change-set   --capabilities CAPABILITY_IAM --profile lab --parameters ParameterKey="8bea57f490d012b9c91fe7306479dbff/260a2064b61858f7d76520d523281770269092e31976c59b5063322f082eef74a2f3954237ca6efee9415dc83b412329a7d2cab83a04dc8815b79ca5772a10f3/72c13a1995c2c66c3fef42e4377a68af66d5f870cc4a559bb6c71b77d3819bb9"
